import numpy as np
import pandas as pd
from fastdtw import fastdtw

# Extract joint_q data from log file
def extract_joint_data(file_path):
    sim_data, real_data = [], []
    with open(file_path, 'r') as f:
        for line in f:
            if "sim_joint_q:" in line:
                values = [float(x) for x in line.split("joint_q:")[1].strip().split(",")[:6]]
                sim_data.append(values)
            elif "real_joint_q:" in line:
                values = [float(x) for x in line.split("real_joint_q:")[1].strip().split(",")[:6]]
                real_data.append(values)
    return np.array(sim_data), np.array(real_data)

# Align simulated data to real data using FastDTW
def align_sim_to_real(sim, real):
    distance, path = fastdtw(sim, real, radius=10)
    theta = 1 - distance / max(len(sim), len(real))
    print("Similarity score (theta):", theta)

    sim_aligned = np.array([sim[i] for i, j in path])
    real_aligned = np.array([real[j] for i, j in path])
    
    return sim_aligned, real_aligned

# Process multiple log files
log_files = [
    "C:/Users/Downloads/log_h21.txt",
    "C:/Users/Downloads/log_h17.txt",
    "C:/Users/Downloads/log_h18.txt",
    "C:/Users/Downloads/log_h19.txt",
    "C:/Users/Downloads/log_h20.txt",
]

mean_diffs_rad_list = []
max_diffs_rad_list = []

for file_path in log_files:
    sim_data, real_data = extract_joint_data(file_path)
    sim_aligned, real_aligned = align_sim_to_real(sim_data, real_data)
    joint_differences = np.abs(sim_aligned - real_aligned)

    mean_diff_rad = np.mean(joint_differences, axis=0)
    max_diff_rad = np.max(joint_differences, axis=0)

    mean_diffs_rad_list.append(mean_diff_rad)
    max_diffs_rad_list.append(max_diff_rad)

# Aggregate results across all files
mean_diffs_rad_array = np.vstack(mean_diffs_rad_list)
max_diffs_rad_array = np.vstack(max_diffs_rad_list)

mean_diff_rad_overall = np.mean(mean_diffs_rad_array, axis=0)
mean_diff_deg_overall = np.degrees(mean_diff_rad_overall)

max_diff_rad_overall = np.mean(max_diffs_rad_array, axis=0)
max_diff_deg_overall = np.degrees(max_diff_rad_overall)

# Create result table
df = pd.DataFrame({
    "Joint": [f"joint_{i+1}" for i in range(6)],
    "Mean Difference (rad)": mean_diff_rad_overall,
    "Mean Difference (deg)": mean_diff_deg_overall,
    "Max Difference (rad)": max_diff_rad_overall,
    "Max Difference (deg)": max_diff_deg_overall,
})

print(df)