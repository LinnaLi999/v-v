import numpy as np
from scipy.spatial.transform import Rotation as R
from fastdtw import fastdtw
import re
import matplotlib.pyplot as plt


def make_transform_matrix(translation, rpy=None, rotation_matrix=None):
    T = np.eye(4)
    T[:3, 3] = translation
    if rotation_matrix is not None:
        T[:3, :3] = rotation_matrix
    elif rpy is not None:
        r = R.from_euler('xyz', rpy)
        T[:3, :3] = r.as_matrix()
    return T


def convert_real_tcp_to_sim(tcp, T_w2b, T_b2bl):
    pos = np.array(tcp[:3])
    rotvec = tcp[3:]
    r_real = R.from_rotvec(rotvec)
    T_real = make_transform_matrix(pos, rotation_matrix=r_real.as_matrix())
    T_sim = T_w2b @ T_b2bl @ T_real
    sim_pos = T_sim[:3, 3]
    sim_quat = R.from_matrix(T_sim[:3, :3]).as_quat()
    return np.concatenate([sim_pos, sim_quat])


def extract_real_and_sim_tcp(log_path):
    real_list = []
    sim_list = []
    with open(log_path, 'r') as f:
        lines = f.readlines()

    i = 0
    while i < len(lines) - 2:
        if "sim tcp trans:" in lines[i] and "sim tcp quat:" in lines[i+1] and "real tcp:" in lines[i+2]:
            try:
                trans = [float(x) for x in lines[i].split("sim tcp trans:")[1].strip().split(',')]
                quat_line = lines[i+1].split("sim tcp quat:")[1].strip()
                quat_vals = re.findall(r"[\w]=([-0-9.eE]+)", quat_line)
                if len(quat_vals) != 4:
                    i += 1
                    continue
                w, x, y, z = map(float, quat_vals)
                sim_quat = [x, y, z, w]
                sim_list.append(trans + sim_quat)

                real = [float(x.strip()) for x in lines[i+2].split("real tcp:")[1].strip().split(',')]
                if len(real) == 6:
                    real_list.append(real)
            except:
                pass
        i += 1
    return np.array(real_list), np.array(sim_list)


def pose_distance(p1, p2, w=1.0):
    pos1, quat1 = p1[:3], p1[3:]
    pos2, quat2 = p2[:3], p2[3:]
    pos_diff = np.linalg.norm(pos1 - pos2)
    rot1 = R.from_quat(quat1)
    rot2 = R.from_quat(quat2)
    relative_rot = rot1.inv() * rot2
    angle_diff = relative_rot.magnitude()
    return pos_diff + w * angle_diff


def align_tcp_by_dtw(real_tcp_7d, sim_tcp_7d):
    _, path = fastdtw(sim_tcp_7d, real_tcp_7d, dist=lambda a, b: pose_distance(a, b, w=0.5), radius=5)
    sim_aligned = np.array([sim_tcp_7d[i] for i, j in path])
    real_aligned = np.array([real_tcp_7d[j] for i, j in path])
    return sim_aligned, real_aligned


def analyze_tcp_error_rmse(sim_aligned, real_aligned):
    sim_pos = sim_aligned[:, :3]
    sim_quat = sim_aligned[:, 3:]
    real_pos = real_aligned[:, :3]
    real_quat = real_aligned[:, 3:]

    pos_error = sim_pos - real_pos
    pos_sq_error = pos_error ** 2
    rmse_xyz = np.sqrt(np.mean(pos_sq_error, axis=0))
    rmse_euclidean = np.sqrt(np.mean(np.linalg.norm(pos_error, axis=1) ** 2))

    sim_euler = R.from_quat(sim_quat).as_euler('xyz', degrees=True)
    real_euler = R.from_quat(real_quat).as_euler('xyz', degrees=True)
    angle_error = (sim_euler - real_euler + 180) % 360 - 180
    angle_sq_error = angle_error ** 2
    rmse_rpy_deg = np.sqrt(np.mean(angle_sq_error, axis=0))

    print("\nTCP Position RMSE (m):")
    print(f"RMSE_x: {rmse_xyz[0]:.6f}, RMSE_y: {rmse_xyz[1]:.6f}, RMSE_z: {rmse_xyz[2]:.6f}")
    print(f"RMSE_total (Euclidean): {rmse_euclidean:.6f} m")

    print("\nTCP Orientation RMSE (Euler angles, deg):")
    print(f"RMSE_roll : {rmse_rpy_deg[0]:.4f}°")
    print(f"RMSE_pitch: {rmse_rpy_deg[1]:.4f}°")
    print(f"RMSE_yaw  : {rmse_rpy_deg[2]:.4f}°")

    return rmse_xyz, rmse_euclidean, rmse_rpy_deg

def plot_3d_tcp_trajectories(sim_aligned, real_aligned):
    from mpl_toolkits.mplot3d import Axes3D

    sim_pos = sim_aligned[:, :3]
    real_pos = real_aligned[:, :3]

    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(real_pos[:, 0], real_pos[:, 1], real_pos[:, 2], label="Real TCP Trajectory", linewidth=2)
    ax.plot(sim_pos[:, 0], sim_pos[:, 1], sim_pos[:, 2], label="Sim TCP Trajectory", linewidth=2)

    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")
    ax.set_title("3D TCP Trajectories (Aligned by DTW)")
    ax.invert_yaxis()
    ax.invert_xaxis()
    ax.legend()
    ax.grid(True)
    plt.tight_layout()
    plt.show()
def plot_tcp_error_curves(sim_aligned, real_aligned):
    pos_sim = sim_aligned[:, :3]
    pos_real = real_aligned[:, :3]
    pos_error = pos_sim - pos_real

    rot_sim = R.from_quat(sim_aligned[:, 3:])
    rot_real = R.from_quat(real_aligned[:, 3:])
    euler_sim = rot_sim.as_euler('xyz', degrees=True)
    euler_real = rot_real.as_euler('xyz', degrees=True)

    def shortest_angle_diff_deg(a, b):
        diff = a - b
        return (diff + 180) % 360 - 180

    euler_error = shortest_angle_diff_deg(euler_sim, euler_real)

    plt.figure(figsize=(10, 4))
    plt.title("TCP Orientation Error per Frame (Euler angles, deg)")
    plt.plot(euler_error[:, 0], label="Roll Error")
    plt.plot(euler_error[:, 1], label="Pitch Error")
    plt.plot(euler_error[:, 2], label="Yaw Error")
    plt.ylabel("Angle Error (°)")
    plt.xlabel("Frame Index")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    log_paths = [
        "C:/Users/Downloads/log_cc9.txt",
        "C:/Users/Downloads/log_cc10.txt",
        "C:/Users/Downloads/log_cc11.txt",
        "C:/Users/Downloads/log_cc29.txt",
    ]

    T_w2b = make_transform_matrix([0.94138, -0.36988, -0.12539])
    T_b2bl = make_transform_matrix([0, 0, 0], rpy=[0, 0, np.pi])

    rmse_xyz_list = []
    rmse_euclidean_list = []
    rmse_rpy_list = []

    for log_path in log_paths:
        print(f"\nAnalyzing file: {log_path}")
        real_tcp_6d, sim_tcp_7d = extract_real_and_sim_tcp(log_path)
        real_tcp_7d = np.array([convert_real_tcp_to_sim(tcp, T_w2b, T_b2bl) for tcp in real_tcp_6d])
        sim_aligned, real_aligned = align_tcp_by_dtw(real_tcp_7d, sim_tcp_7d)
        plot_3d_tcp_trajectories(sim_aligned, real_aligned)
        rmse_xyz, rmse_euclidean, rmse_rpy_deg = analyze_tcp_error_rmse(sim_aligned, real_aligned)
        rmse_xyz_list.append(rmse_xyz)
        rmse_euclidean_list.append(rmse_euclidean)
        rmse_rpy_list.append(rmse_rpy_deg)

    mean_rmse_xyz = np.mean(rmse_xyz_list, axis=0)
    mean_rmse_euclidean = np.mean(rmse_euclidean_list)
    mean_rmse_rpy = np.mean(rmse_rpy_list, axis=0)

    print("\nAverage RMSE across all logs:")
    print(f"Mean XYZ RMSE: {mean_rmse_xyz}")
    print(f"Mean Euclidean RMSE: {mean_rmse_euclidean:.6f} m")
    print(f"Mean Orientation RMSE (roll, pitch, yaw): {mean_rmse_rpy} °")