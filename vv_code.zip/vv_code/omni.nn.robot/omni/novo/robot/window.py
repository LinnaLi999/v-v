__all__ = ["RobotWindow"]

import os
import time
import omni
import omni.ui as ui
import asyncio
import numpy as np
import carb.events
import omni.usd
from typing import List
from .style import example_window_style, playback_icon_path, stop_icon_path
from .color_widget import ColorWidget
from omni.sdu.core.robots.ur_robot_sim import URRobotSim
from omni.kit.window.popup_dialog import FormDialog
from omni.isaac.core.prims.xform_prim import XFormPrim
from omni.isaac.core.utils.prims import get_prim_at_path, get_prim_path, get_prim_type_name
from omni.isaac.core.utils.prims import is_prim_path_valid, get_all_matching_child_prims
from omni.isaac.ui.ui_utils import build_simple_search, SearchListItemModel, SearchListItemDelegate
from omni.kit.widgets.custom import TitleWindowBase, SimpleListView, SimpleListItem, SimpleListModel
from pxr import Usd, UsdPhysics
from rtde_control import RTDEControlInterface as RTDEControl
from rtde_receive import RTDEReceiveInterface as RTDEReceive
from rtde_io import RTDEIOInterface as RTDEIo
from omni.isaac.core import World
from omni.isaac.core.utils.stage import (
    create_new_stage_async
)
import rtde_control


from pxr import Sdf
import omni.kit.commands
import threading
thread_lock = threading.Lock()

LABEL_WIDTH = 120
SPACING = 4

# Traverse stage and find any articulation roots.
# https://docs.omniverse.nvidia.com/dev-guide/latest/programmer_ref/usd/hierarchy-traversal/find-prim-by-name.html
# and omni.isaac.core.utils get_articulation_root_api_prim_path() and get_prim_object_type()

def find_prims_by_name(stage: Usd.Stage, prim_name: str) -> List[Usd.Prim]:
    found_prims = [x for x in stage.Traverse() if x.GetName() == prim_name]
    return found_prims

def find_articulation_roots(stage: Usd.Stage) -> List[Usd.Prim]:
    found_articulation_roots = [x for x in stage.Traverse() if x.HasAPI(UsdPhysics.ArticulationRootAPI)]
    #print("Found articulation roots:", found_articulation_roots)
    return found_articulation_roots

def find_ee_joints(ee_prim_path = ''):
    # get all joints under ee prim
    joint_prims = get_all_matching_child_prims(prim_path=ee_prim_path,
                                               predicate=lambda a: "Joint" in get_prim_type_name(a))
    return joint_prims


class RobotRTDE(XFormPrim, RTDEControl, RTDEReceive, RTDEIo):
    def __init__(self, ip: str, prim_path: str, name: str):
        self.ip = ip
        # self.rtde_c = rtde_control.RTDEControlInterface(self.ip)
    
        RTDEControl.__init__(
            self, ip, flags=RTDEControl.FLAG_VERBOSE | RTDEControl.FLAG_UPLOAD_SCRIPT
        )
        RTDEReceive.__init__(self, ip, -1.0, [])
        RTDEIo.__init__(self, ip)
        XFormPrim.__init__(self, prim_path=prim_path, name=name)

    def initialize(self, physics_sim_view=None) -> None:
        """To be called before using this class after a reset of the world

        Args:
            physics_sim_view (_type_, optional): _description_. Defaults to None.
        """
        XFormPrim.initialize(self, physics_sim_view=physics_sim_view)
        initial_joint_q = [0.0, -1.5707, -1.5707, -1.5707, 1.5707, 0.0]
        self.moveJ(initial_joint_q, 0.1, 1.4, True)
        
        return

    def post_reset(self) -> None:
        # XFormPrim.post_reset(self)
        return


class RobotWindow(ui.Window):
    """The class that represents the window"""

    def __init__(self, title: str, delegate=None, **kwargs):
        self.__label_width = LABEL_WIDTH

        super().__init__(title, **kwargs)

        # Apply the style to all the widgets of this window
        self.frame.style = example_window_style
        # Set the function that is called to build widgets when the window is
        # visible
        self.frame.set_build_fn(self._build_fn)

        self._listview_sim = None
        self._listview_real = None

        self._model_sim = None
        self._model_real = None
        self._world = None
        self._sim_robots = []
        self._real_robots = []
        self._init_btn = None
        self._reset_btn = None
        self._world_initialized = False

        self._combo_sub = None
        self._combo_options = ["Simulation", "Real", "Both"]

        # Event is unique integer id. Create it from string by hashing, using helper function.
        # [ext name].[event name] is a recommended naming convention:
        self.ROBOT_EXECUTION_EVENT = carb.events.type_from_string("omni.graph.action.ROBOT_EXECUTION_EVENT")

        # App provides common event bus. It is event queue which is popped every update (frame).
        self._bus = omni.kit.app.get_app().get_message_bus_event_stream()


        timeline = omni.timeline.get_timeline_interface()
        timeline_events = timeline.get_timeline_event_stream()
        self.timeline_event_sub = timeline_events.create_subscription_to_pop(
            self._on_timeline_event)
        
    def _on_event(self, e):
        print(e.type, e.type == self.ROBOT_EXECUTION_EVENT, e.payload)


    def _on_timeline_event(self, event: carb.events.IEvent):
        if event.type == int(omni.timeline.TimelineEventType.STOP):
            print("Pressed stop")
            if self._sim_robots:
                self._custom_reset()
        
    def _custom_reset(self):
        self._reset_robots(should_clear=False)
        asyncio.ensure_future(self._on_reset_world_async())

    async def _on_load_world_async(self):
        if not World.instance():
            self._world = World(stage_units_in_meters=1.0)
        else:
            self._world = World.instance()
        
        await self._world.initialize_simulation_context_async()
        
       

        omni.kit.commands.execute('ChangeProperty',
            prop_path=Sdf.Path('/physicsScene.physxScene:enableGPUDynamics'),
            value=True,
            prev=None,
            target_layer=Sdf.Find('file:/home/nyll/Desktop/project/sdu/CALI33.usd'),
            usd_context_name=omni.usd.get_context().get_stage())
        await omni.kit.app.get_app().next_update_async()
        await self._world.reset_async()

        if self._world is not None:
            
            articulation_roots = find_articulation_roots(self._world.stage)
            print("artu root",articulation_roots)
            for root in articulation_roots:
                robot_type = root.GetName()
                robot_name = root.GetParent().GetName()
                if not '_ghost' in robot_name:
                    if self._listview_sim.items:
                        for item in self._listview_sim.items:  
                            item_name = item.get_value_model(1).get_value_as_string()
                            if item_name != robot_name:
                                self._add_robot(robot_type=robot_type, name=robot_name)
                    else:
                        self._add_robot(robot_type=robot_type, name=robot_name)
                print(robot_type+':')
                print('\t'+robot_name)

        if self._listview_sim.items:
            self._init_btn.enabled = True
            self._reset_btn.enabled = True

        #await self._world.pause_async()

    async def _on_reset_world_async(self, reset_soft=True):
        await self._world.initialize_simulation_context_async()
        omni.kit.commands.execute('ChangeProperty',
            prop_path=Sdf.Path('/physicsScene.physxScene:enableGPUDynamics'),
            value=True,
            prev=None,
            target_layer=Sdf.Find('file:/home/nyll/Desktop/project/sdu/CALI33.usd'),
            usd_context_name=omni.usd.get_context().get_stage())
        await omni.kit.app.get_app().next_update_async()
        await self._world.reset_async(soft=False)
        await self._world.pause_async()
        

    def _remove_selected(self):
        self._listview_sim.remove_selected()

    def _clear_simulated_robots(self):
        self._listview_sim.clear()

    def _clear_real_robots(self):
        self._listview_real.clear()

    def _disconnect_real_robot(self):
        selected_items = self._listview_real.selection_items
        if not selected_items:
            for real_robot in self._real_robots:
                real_robot_rtde = real_robot['rtde']
                real_robot_rtde.stopScript()
                time.sleep(0.3)
                self._world.scene.remove_object(real_robot['name'] + '_physical')
                del real_robot_rtde
                if self._listview_real.items:
                    for item in self._listview_real.items:
                        #item.get_value_model(2).set_value("")
                        item.get_value_model(3).set_value("Disconnected")
                    del real_robot
                    self._real_robots.clear()
        else:
            for item in selected_items:
                for real_robot in self._real_robots:
                    robot_name = item.get_value_model(1).get_value_as_string()
                    if real_robot['name'] == robot_name:
                        real_robot_rtde = real_robot['rtde']
                        real_robot_rtde.stopScript()
                        time.sleep(0.3)
                        self._world.scene.remove_object(real_robot['name'] + '_physical')
                        del real_robot_rtde
                        #item.get_value_model(2).set_value("")
                        item.get_value_model(3).set_value("Disconnected")
                        del real_robot
                        self._real_robots.clear()

    def _add_robot(self, robot_type, name, robot_ip='', status="Disconnected"):
        self._listview_sim.insert(SimpleListItem([robot_type, name, "Uninitialized"]))
        self._listview_real.insert(SimpleListItem([robot_type, name, robot_ip, "Disconnected"]))

    def _init_real_robot(self, robot_name, robot_ip):
        
        robot_rtde = RobotRTDE(ip=robot_ip, 
                               prim_path="/World/Robots/" + robot_name + '_physical', 
                               name=robot_name + '_physical'
        )
        robot_rtde.initialize()
        physical_robot = {'name': robot_name, 'rtde': robot_rtde}
        self._real_robots.append(physical_robot)
        self._world.scene.add(robot_rtde)

                        
    def _connect_robot_dialog_cb(self, option):
        robot_ip = self._robot_dialog.get_value('robot_ip')
        robot_verbose = self._robot_dialog.get_value('robot_verbose')

        selected_items = self._listview_real.selection_items
        if not selected_items:
            print("Please select a robot to connect to!")
        else:
            for item in selected_items:
                robot_name = item.get_value_model(1).get_value_as_string()
                #try:
                self._init_real_robot(robot_name, robot_ip)
                item.get_value_model(2).set_value(robot_ip)
                item.get_value_model(3).set_value("Connected")
                print(robot_name + ' connected with ip: ' + robot_ip)
                #except:
                    #print(robot_name + " is already connected.")
        
        self._robot_dialog.hide()

    def _build_robot_dialog(self) -> FormDialog:
        field_defs = [
            FormDialog.FieldDef("robot_ip", "IP-address:  ", ui.StringField, "169.254.101.27"),
            FormDialog.FieldDef("robot_verbose", "Verbose:  ", ui.CheckBox, True)
        ]
        dialog = FormDialog(
            title="Connect to robot",
            message="Please enter values for the following fields:",
            field_defs=field_defs,
            ok_handler=self._connect_robot_dialog_cb,
        )
        return dialog
    
    def _load_world(self):
        # Load the world
        asyncio.ensure_future(self._on_load_world_async())

    def _find_robots(self):
        if not self._world_initialized:
            self._load_world()
            self._world_initialized = True
        else:
            print("World already initialized, look for any additional robots")
            if self._world is not None:
                articulation_roots = find_articulation_roots(self._world.stage)
                for root in articulation_roots:
                    robot_type = root.GetName()
                    robot_name = root.GetParent().GetName()
                    if not '_ghost' in robot_name:
                        if self._listview_sim.items:
                            item_names = [i.get_value_model(1).get_value_as_string() for i in self._listview_sim.items]
                            if robot_name not in item_names:        
                                self._add_robot(robot_type=robot_type, name=robot_name)
                                print('Adding '+robot_type+':')
                                print('\t'+robot_name)
                        else:
                            print('robot list empty')
                            self._add_robot(robot_type=robot_type, name=robot_name)
                            print('Adding '+robot_type+':')
                            print('\t'+robot_name)

    def _init_robot(self, robot_name, robot_type, calibrated_urdf_path=''):
         # Initialize simulated robots
        found_prims = find_prims_by_name(self._world.stage, robot_name)
        robot_prim = found_prims[0]
        robot_prim_path = robot_prim.GetPrimPath().pathString
        print("robot_type: ", robot_type)
        robot_xform_prim = XFormPrim(prim_path=robot_prim_path + "/" + robot_type)
        robot_base_isaac_pose = robot_xform_prim.get_world_pose()
        ee_joints = find_ee_joints(robot_prim_path + '/' + robot_type + '/tool0')
        initial_joint_q = np.array([0.0, -1.5707, -1.5707, -1.5707, 1.5707, 0])
        
        
        # if robot has a gripper, append two more joint positions to the initial joint positions.
        if len(ee_joints) > 0:
            print(robot_name + ' has a gripper!')
            initial_joint_q = np.append(initial_joint_q, np.zeros(2))

        if calibrated_urdf_path:
            print("Using calibrated_urdf_path: ", calibrated_urdf_path)

        robot = URRobotSim(
            robot_type=robot_type,
            prim_path=robot_prim_path,
            name=robot_name + "_articulation",
            initial_joint_q=initial_joint_q,
            calibrated_urdf_path=calibrated_urdf_path,
            position=robot_base_isaac_pose[0],
            orientation=robot_base_isaac_pose[1]
        )
        robot.initialize_controller()
        robot.initialize()
        self._world.scene.add(robot)
        self._sim_robots.append(robot)
        # print("pos1",robot.get_joint_positions())

    def _initialize_robots(self):
        omni.kit.commands.execute('ChangeProperty',
            prop_path=Sdf.Path('/physicsScene.physxScene:enableGPUDynamics'),
            value=True,
            prev=None,
            target_layer=Sdf.Find('file:/home/nyll/Desktop/project/sdu/CALI33.usd'),
            usd_context_name=omni.usd.get_context().get_stage())
        selected_items = self._listview_sim.selection_items
        if not selected_items:
            for item in self._listview_sim.items:
                robot_type = item.get_value_model(0).get_value_as_string()
                robot_name = item.get_value_model(1).get_value_as_string()
                try:
                    self._init_robot(robot_name, robot_type)
                    item.get_value_model(2).set_value("Initialized")
                    print(robot_name + ' initialized.')
                except:
                    print(robot_name + " has already been initialized.")
        else:
            for item in selected_items:
                robot_type = item.get_value_model(0).get_value_as_string()
                robot_name = item.get_value_model(1).get_value_as_string()
                try:
                    self._init_robot(robot_name, robot_type)
                    item.get_value_model(2).set_value("Initialized")
                    print(robot_name + ' initialized.')
                except:
                    print(robot_name + " has already been initialized.")

        # Initialize physics
        self._world.initialize_physics()

        # Call to world reset to make sure everything is properly initialized.
        self._world.reset(soft=True)
        self._world.play()

    def _reset_robots(self, should_clear = True):
        selected_items = self._listview_sim.selection_items
        if not selected_items:
            for item in self._listview_sim.items:
                robot_name = item.get_value_model(1).get_value_as_string()
                if self._world.scene.object_exists(robot_name + '_articulation'):
                    self._world.scene.remove_object(robot_name + '_articulation')
                for robot in self._sim_robots:
                    if robot.name == robot_name:
                        del robot
                item.get_value_model(2).set_value("Uninitialized")
                print(robot_name + ' reset successfully.')
        else:
            for item in selected_items:
                robot_name = item.get_value_model(1).get_value_as_string()
                if self._world.scene.object_exists(robot_name + '_articulation'):
                    self._world.scene.remove_object(robot_name + '_articulation')
                for robot in self._sim_robots:
                    if robot.name == robot_name:
                        del robot
                item.get_value_model(2).set_value("Uninitialized")
                print(robot_name + ' reset successfully.')

        if should_clear:
            self._listview_sim.clear()
            self._listview_real.clear()
        
        # Call to world reset to make sure everything is properly initialized.
        # self._world.reset(soft=True)

    def _robot_execute(self):
        print("Starting simulation")
        omni.kit.commands.execute('ChangeProperty',
            prop_path=Sdf.Path('/physicsScene.physxScene:enableGPUDynamics'),
            value=True,
            prev=None,
            target_layer=Sdf.Find('file:/home/nyll/Desktop/project/sdu/CALI33.usd'),
            usd_context_name=omni.usd.get_context().get_stage())
        # Push event bus with custom payload
        self._bus.push(self.ROBOT_EXECUTION_EVENT, payload={"execution_mode": 1})

    def _stop_robot(self):
        print("Stop simulation") 
        if self._sim_robots:
            self._custom_reset()

    def destroy(self):
        # It will destroy all the children
        super().destroy()

    @property
    def label_width(self):
        """The width of the attribute label"""
        return self.__label_width

    @label_width.setter
    def label_width(self, value):
        """The width of the attribute label"""
        self.__label_width = value
        self.frame.rebuild()

    def _build_collapsable_header(self, collapsed, title):
        """Build a custom title of CollapsableFrame"""
        with ui.HStack():
            ui.Label(title, name="collapsable_name")

            if collapsed:
                image_name = "collapsable_opened"
            else:
                image_name = "collapsable_closed"
            ui.Image(name=image_name, width=20, height=20)

    def _build_simulation_controls(self):
        with ui.VStack(height=0, spacing=SPACING):
                ui.Label("Robot controls:")
                ui.Spacer(height=5)
                with ui.HStack(spacing=0):
                    ui.Label("Run in:")
                    combo_model: ui.AbstractItemModel = ui.ComboBox(0, *self._combo_options).model

                    def combo_changed(item_model: ui.AbstractItemModel, item: ui.AbstractItem):
                        value_model = item_model.get_item_value_model(item)
                        current_index = value_model.as_int
                        option = self._combo_options[current_index]
                        print(f"Selected '{option}' at index {current_index}.")
                    
                    self._combo_sub = combo_model.subscribe_item_changed_fn(combo_changed)

                ui.Spacer(height=5)

                with ui.HStack(spacing=SPACING):
                    ui.Button("Start", height=52, image_url=playback_icon_path, clicked_fn=self._robot_execute)
                    ui.Button("Stop", height=52, image_url=stop_icon_path, clicked_fn=self._stop_robot)

    def _build_simulated_robots(self):
        """Build the widgets of the "Simulated robots" group"""
        with ui.CollapsableFrame("Simulated Robots", name="group", build_header_fn=self._build_collapsable_header):
            with ui.VStack(height=0, spacing=SPACING):
                with ui.HStack():
                    ui.Label("Type", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=10)
                    ui.Label("Name", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=205)
                    ui.Label("Status", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=130)
                    #ui.Spacer(width=ui.Fraction(0.4))
                    #ui.Spacer(width=150)   
                    #ui.Spacer(width=500)

                self._model_sim = SimpleListModel(columns_count=3)
                self._listview_sim = SimpleListView(height=150, 
                                                model=self._model_sim, 
                                                multi_selection=True, 
                                                column_widths=[ui.Fraction(0.1),
                                                               ui.Fraction(0.6),
                                                               ui.Fraction(0.3)])
                                                #column_widths=[ui.Length(55.0),, ui.Fraction(0.6)
                                                #ui.Length(135.0),
                                                #ui.Length(150.0),
                                                #ui.Length(600.0)])                     

                self._robot_dialog = self._build_robot_dialog()

                with ui.HStack():
                    self._find_robots_btn = ui.Button("Find robots", height=26, clicked_fn=self._find_robots)
                    self._init_btn = ui.Button("Initialize", height=26, clicked_fn=self._initialize_robots)
                    self._reset_btn = ui.Button("Reset", height=26, clicked_fn=self._reset_robots)

                    self._init_btn.enabled = False
                    self._reset_btn.enabled = False
                    # ui.Spacer(width=400)

    def _build_physical_robots(self):
        """Build the widgets of the "Physical robots" group"""
        with ui.CollapsableFrame("Physical Robots", name="group", build_header_fn=self._build_collapsable_header):
            with ui.VStack(height=0, spacing=SPACING):
                with ui.HStack():
                    ui.Label("Type", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=10)
                    ui.Label("Name", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=102)
                    ui.Label("IP-address", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=102)
                    ui.Label("Status", style_type_name_override="TreeView.Header")
                    ui.Spacer(width=85)
                    # ui.Spacer(width=500)
            
                self._model_real = SimpleListModel(columns_count=4)
                self._listview_real = SimpleListView(height=150,
                                                model=self._model_real,
                                                multi_selection=True,
                                                column_widths=[ui.Fraction(0.1),
                                                               ui.Fraction(0.3),
                                                               ui.Fraction(0.3),
                                                               ui.Fraction(0.3)])
                
                self._robot_dialog = self._build_robot_dialog()

                with ui.HStack():
                    ui.Button("Connect", height=26, clicked_fn=self._robot_dialog.show)
                    ui.Button("Disconnect", height=26, clicked_fn=self._disconnect_real_robot)
                    # ui.Spacer(width=400)
            

    def _build_fn(self):
        """
        The method that is called to build all the UI once the window is
        visible.
        """

        with ui.ScrollingFrame():
            with ui.VStack(height=0):
                #with ui.VStack():
                #    #ui.Button("Load", height=26, clicked_fn=self._load_world)
                self._build_simulation_controls()
                ui.Spacer(height=10)
                self._build_simulated_robots()
                self._build_physical_robots()

                # self._build_parameters()
                # self._build_light_1()
#