import rtde_receive
from time import sleep
import rtde_control


robot_ip = "192.168.1.11"



rtde_r = rtde_receive.RTDEReceiveInterface(robot_ip)


count = 0



print("Press enter to save TCP pose or type the pose name and press enter")
while True:
	try:
		text = input("")  # or raw_input in python2
		if text == "":
			actual_tcp = rtde_r.getActualTCPPose()
			actual_q = rtde_r.getActualQ()
			print(count)
			print("TCP: ", actual_tcp)
			print("Q  : ", actual_q)
			print("\n")
			count += 1
		elif text is not None:
			print("\n\nPose: %s" % text)
			count = 0

	except KeyboardInterrupt:
		
		print("stopping...")

		rtde_r.disconnect()
		break






