from omni.isaac.core import World

import omni.graph.core as og

from omni.isaac.core_nodes import BaseResetNode

import threading

from omni.sdu.ur.ogn.OgnGripperCloseNodeDatabase import OgnGripperCloseNodeDatabase

from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended

from omni.isaac.core.articulations import Articulation

import numpy as np

import time


class OgnGripperCloseInternalState(BaseResetNode):

    def __init__(self):

        self.initialized = False

        self.task_thread = None

        self.is_task_done = False

        self.intermediate_pos = []

        super().__init__(initialize=False)

    def initialize_task(self, db):
        
        """Initialize the gripper and start the task."""

        self.world = World.instance()

        prim_path = db.inputs.gripper

        # self.robot = self.world.scene.get_object(db.inputs.gripper+'_articulation')
        # print(self.robot)

        self.gripper = Articulation(prim_path=prim_path)

        self.gripper.initialize()

        db.log_info(f"Current position: {self.get_current_position(db)}")

        db.log_info("Opening gripper...")

        

        # Mark as initialized

        self.initialized = True



    def get_current_position(self, db):

        """Get the current joint positions of the gripper."""

        db.log_info("Fetching current gripper position")

        return self.gripper.get_joint_positions()

    def perform_task(self, db):
        
        """Simulated task execution."""


        try:
            print("4.1")
            db.log_info("Performing task...")
            dis = db.inputs.distance
            print(dis)
            current_pos = self.get_current_position(db)
            target_pos = current_pos.copy()
            target_pos[-2:] = [dis, dis]
            self.gripper.set_joint_positions(target_pos)
            
 

            

            self.is_task_done = True
            db.outputs.success = og.ExecutionAttributeState.LATENT_FINISH


            db.log_info("Task completed.")

        except Exception as e:
           
            db.log_warn(f"Error during task execution: {e}")

            self.is_task_done = False

    def evaluate_task(self, db) -> bool:
  
        """Evaluate the success of the task."""

        return self.is_task_done

    def check_preconditions(self, db) -> bool:
       
        """Check preconditions before starting the task."""

        if not db.inputs.gripper:

            db.log_warn("Please specify a gripper to use")

            return False
        
        return True


    def custom_reset(self):
     
        """Reset the internal state."""

        self.is_task_done = False

        if self.initialized:

            if self.task_thread:

                self.task_thread.join()

                self.task_thread = None

        self.initialized = False


class OgnGripperCloseNode:
    """Node for controlling and closing the gripper."""

    @staticmethod

    def internal_state():

        return OgnGripperCloseInternalState()

    @staticmethod

    def compute(db) -> bool:
        # print("8")
        """Main compute function."""

        try:

            state = db.internal_state

            if not state.initialized:
                print("8.1")
                indicate_node_exec_running(db.node)

                state.initialize_task(db)

                if not state.check_preconditions(db):
                    print("8.2")
                    indicate_node_exec_ended(db.node)

                    return False

                # Start task thread

                state.task_thread = threading.Thread(target=state.perform_task, args=(db,))

                state.task_thread.start()

                
                state.initialized = True
                
                db.outputs.success = og.ExecutionAttributeState.LATENT_PUSH

                


                
           

            if state.is_task_done:

                indicate_node_exec_ended(db.node)

                success = state.evaluate_task(db)

                if success:

                    db.outputs.success = og.ExecutionAttributeState.LATENT_FINISH

                    return True

                else:

                    return False

        except Exception as error:

            db.log_warn(f"Error in computation: {error}")

            return False

        # Task still running

        
        return True

    @staticmethod

    def release(node):
        print("9")
        """Release resources and reset the state."""

        try:

            state = OgnGripperCloseNodeDatabase.per_node_internal_state(node)

        except Exception:

            state = None

        if state is not None:

            state.custom_reset() 
