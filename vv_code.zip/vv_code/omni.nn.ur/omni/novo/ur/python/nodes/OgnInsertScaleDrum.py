"""
This is the implementation of the OGN node defined in OgnInsertScaleDrum.ogn
"""
from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core_nodes import BaseResetNode
import numpy as np
import threading
import time 
from scipy.spatial.transform import Rotation as R
from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended
import os
from omni.sdu.ur.ogn.OgnInsertScaleDrumDatabase import OgnInsertScaleDrumDatabase
class OgnInsertScaleDrumInternalState(BaseResetNode):

    def __init__(self):
        self.initialized = False
        self.task_thread = None
        self.is_task_done = False
        #self.pose_db = None
        self.robot_rtde = None
        self.gripper = None
        self.WeissGripper = None
        self.recipe = None
        super().__init__(initialize=False)

    def initialize_task(self, db):
        # Attempt to retrieve the specified pose from the database
        
        # attempt to get pose database from world
        self.world = World.instance()
        if self.world is None:
            db.log_warn("The world died...")
        else:
            # attempt to get specified robot from World
            self.robot_rtde = self.world.scene.get_object(db.inputs.urRobot+'_physical')
            if self.robot_rtde is None:
                db.log_warn("The node found no robot to mov, please provide a robot!")
            
            self.insertionForce = db.inputs.insertionForce
            if self.insertionForce is None:
                db.log_warn("Please specify an insertion force!")
            
            self.insertionTorque = db.inputs.insertionTorque
            if self.insertionTorque is None:
                db.log_warn("Please specify an insertion force!")
            # get gripper
            obj_name = os.path.basename(db.inputs.gripper) + '_real'
        
            self.gripper = self.world.scene.get_object(obj_name )
            if self.gripper is None:
                db.log_warn("The node found no gripper, please provide a gripper!")
            # get specified gripper from World      
            # self.WeissGripper = db.inputs.WeissGripper
            # if self.WeissGripper == False:
            #     self.gripper = world.scene.get_object(db.inputs.gripper + '_real')
            #     if self.gripper is None:
            #         db.log_warn("The node found no gripper, please provide a gripper!")
            # else:
            #     self.recipe = db.inputs.gripperRecipe
            #     if self.recipe is None:
            #         db.log_warn("The gripper got no recipe number (0-8)!")
            

            self.task_thread = threading.Thread(target=self.perform_task, args=(db,), daemon=False)

    def perform_task(self, db):
        """
        Perform task or skill in a separate thread to avoid freezing the main UI thread.

        Parameters:
            db : internal node data 
            
        Task:
            3 main steps:
                1. From the place position the robot will move until contacting the housing with the scaledrum
                2. The robot will start rotating in forcemode until it starts screewing the scaledrum into the housing:
                    Breaks if:
                        - Exceeds max allowed rotatation (will try to screw it again)
                        - Displacement of z > threshold
                3. Continue screewing in forcemode in Z and moveJ for rotation to ensure insertion
        """
        
        # ===== Move 6th joint to an intermediate value =====
        print("Moving 6th joint to a intermediate value...")
        db.log_info("[Force mode] Moving 6th joint to a intermediate value ...")
        pose = self.robot_rtde.getActualQ()
        init_cartesian = self.robot_rtde.getActualTCPPose()
        init_q = self.robot_rtde.getActualQ()
        print("pose init",pose)
        # Task parameters:
        if self.insertionTorque > 0:
            RZ = 1.5*np.pi #np.pi/2
        else:
            RZ = -np.pi/2

        pose[5] = RZ
        print("rz",RZ)
        print("pose",pose)
        task_frame = [0, 0, 0, 0, 0, 0] # Base-TCP force c.s. transform
        frame_transform_type = 2 # read API
        compliance_vector = [0, 0, 1, 0, 0, 1] # Set compliant axis
        speed = [0, 0, -0.01, 0, 0, 0]    
        F_insert = np.zeros(6)
        F_insert[2] = self.insertionForce  #[0, 0, -self.insertionForce] # Virtual force in base frame
        F_insert[5] = self.insertionTorque
        # F_insert[2] = -3  #[0, 0, -self.insertionForce] # Virtual force in base frame
        # F_insert[5] = 7
        print("insert F",F_insert)
        vMax = [0.1, 0.1, 2, 0.1, 0.1, 2] # Maximum resulting velocity [m/s, m/s, m/s, rad/s, rad/s, rad/s]
        max_allowed_rotation =  2.5*np.pi
        screwInRotation = np.pi

        time.sleep(0.3)
        self.robot_rtde.zeroFtSensor() # reset force sensor due to drift
        time.sleep(0.3)

        self.robot_rtde.moveJ(pose, 2, 2)
        
        state= self.move_until_contact_force_based(speed_vec=speed, force_threshold=6,axis=2,timeout=100)
        # print("state",state)
        # if state :
        #     self.robot_rtde.speedL([0.0]*6,0.1,0.1)
        # RZ1 = 0
        # pose[5] = RZ1
        # self.robot_rtde.moveJ(pose, 2, 2)
        # self.is_task_done = True

        
        # # ===== Small insert force to assure contact =====
        try:
            print("Initialization small insert force to assure contact...")
            # Force mode parameters
            searchingForInsert = True

            tcp_pose_initial = self.robot_rtde.getActualTCPPose()
            initial_q = self.robot_rtde.getActualQ()
            
            #Rotate with insertionTorque while pressing with insertionForce
            i = 0
            while(searchingForInsert):
                t_start = self.robot_rtde.initPeriod()

                current_q = self.robot_rtde.getActualQ()
                current_tcp_pose = self.robot_rtde.getActualTCPPose()

                self.robot_rtde.forceMode(task_frame, compliance_vector, F_insert.tolist(), frame_transform_type, vMax)
                if current_tcp_pose[2] - tcp_pose_initial[2] < -0.003:
                    print("FOUND INSERTION IN ROBOT ", db.inputs.urRobot)
                    self.robot_rtde.forceModeStop()
                    searchingForInsert = False
                    
                elif abs(current_q[5] - initial_q[5]) >= max_allowed_rotation or abs(current_q[5]) > 1.75 * np.pi:
                    self.robot_rtde.forceModeStop()
                    print("TCP OF ROBOT " + db.inputs.urRobot + " EXCEEDED THE MAXIMUM ROTATION")
                    db.log_error("The insertion node couldn't insert properly!! Exceeded max rotation!")
                    # recovery_pose = self.robot_rtde.getActualQ()
                    # RZ = 1.5*np.pi 
                    # recovery_pose[5] = RZ
                    # self.robot_rtde.moveJ(recovery_pose, 1, 0.5) # Rotate to the other extrem of the 6th joint and try egain inserting
                    # initial_q = self.robot_rtde.getActualQ()
                    searchingForInsert = False
                
                self.robot_rtde.waitPeriod(t_start)
            # self.is_task_done = True

        #     # ==== AFTER FINDING INSERTION, CONTINUE SCREEWING TO ENSURE INSERTION ====
            print("SCREEWING A BIT MORE TO ENSURE INSERTION IN THE ROBOT ", db.inputs.urRobot)
            initial_q = self.robot_rtde.getActualQ()
            screwingIn = True
            compliance_vector = [0, 0, 1, 0, 0, 0]
            F_insert[5] = 0
            self.robot_rtde.forceMode(task_frame, compliance_vector, F_insert.tolist(), frame_transform_type, vMax)
            
            current_q = self.robot_rtde.getActualQ()
            moveQ = current_q
            moveQ[5] = -1.5 * np.pi
            self.robot_rtde.moveJ(moveQ, 0.75, 1, asynchronous=True) # ensure screewing is done by force mode in Z and moveJ for rotation of the tcp
            
            while screwingIn:
                current_q = self.robot_rtde.getActualQ()
                # print("current_q: ", current_q)
                # print("initial_q: ", initial_q)
                # print("diff: ", current_q[5] - initial_q[5])
                # print("screwInRotation: ", screwInRotation)
                if abs(current_q[5] - initial_q[5]) >= screwInRotation or abs(current_q[5]) > 1.45 * np.pi:
                    self.robot_rtde.stopJ(1.0, False)
                    print("Stop continue screwing")
                    screwingIn = False
                time.sleep(0.1)
            
            # stop force mode and unwind joint 6
            self.robot_rtde.forceModeStop()
            # Release scaledrum
            if self.WeissGripper == False:
                self.gripper.move_and_wait_for_pos(self.gripper.get_closed_position(), 255, 1)
            else:
                self.gripper.move_and_wait_for_pos(self.gripper.get_closed_position(), 255, 1)
                # self.robot_rtde.setInputIntRegister(18, 2)
                # self.robot_rtde.setInputIntRegister(19, 2) #release scale drum
                time.sleep(2)
            # move linearly to a slightly higher position and come back to the init pose
            higher_pose = self.robot_rtde.getActualTCPPose()
            higher_pose[2] = init_cartesian[2]
            self.robot_rtde.moveL(higher_pose, 1.4, 1)
            self.robot_rtde.moveJ(init_q, 1.8, 1.3)
            
            self.is_task_done = True
    
        except Exception as e:
            db.log_warn("[Force mode] Robot " + str(db.inputs.urRobot) + " Failed! Exception: " + str(e))
            self.is_task_done = False


    def evaluate_task(self, db) -> bool:
        """
        Evaluate and if possible verify whether the task or skill was successfully performed. If this task 
        is performed successfully and it can verified that it was done correctly this function returns True.
        If that is not the case False is returned. 

        Parameters:
            db : internal node data 

        Returns:
            success(bool) : True if preconditions are met, False otherwise
        """
        success = True
        return success

    def check_preconditions(self, db) -> bool:
        """
        Check any preconditions for performing this task or skill, if a precondition 
        is not met False should be returned, other this function returns True by default.

        Parameters:
            db : internal node data 

        Returns:
            preconditions_met(bool) : True if preconditions are met, False otherwise
        """
        preconditions_met = True
            
        if not db.inputs.urRobot:
            db.log_warn("Please specify a UR robot to use for this movement!")
            preconditions_met = False
        
        if db.inputs.WeissGripper == False:
            if not db.inputs.gripper:
                db.log_warn("Please specify the gripper to actuate!")
                preconditions_met = False
        else:
            if not db.inputs.gripperRecipe:
                db.log_warn("The gripper got no recipe number (0-8)!")
                preconditions_met = False
        
        return preconditions_met
    
    def reset_vars(self):
        self.is_task_done = False
        if self.initialized:
           if self.task_thread:
               self.task_thread.join()
               self.task_thread = None
        self.initialized = False
    
    def custom_reset(self):
        self.reset_vars()
        if self.robot_rtde is not None:      
            del self.robot_rtde
            self.robot_rtde = None
    
    def get_base_tcp_transform(self, pose):

        tcp_pose = np.asarray(pose)

        rot = R.from_rotvec(tcp_pose[3:6]).as_matrix()

        t = np.empty(3)
        t[0:3] = tcp_pose[0:3]

        T = np.identity(4)
        T[0:3, 0:3] = rot
        T[0:3, 3] = t
        return np.linalg.inv(T)

    def skew_symmetric(self, vector):
        x = vector[0]
        y = vector[1]
        z = vector[2]
        Sv = np.zeros((3, 3))
        Sv[1, 0] = z
        Sv[2, 0] = -y
        Sv[0, 1] = -z
        Sv[2, 1] = x
        Sv[0, 2] = y
        Sv[1, 2] = -x
        return Sv

    def adjoint(self, matrix):
        # Assumes input is 4x4 transformation matrix
        R_mat = matrix[0:3, 0:3]
        p = matrix[0:3, 3]

        adj_T = np.zeros((6, 6))
        adj_T[0:3, 0:3] = R_mat
        adj_T[3:6, 0:3] = self.skew_symmetric(p) @ R_mat
        adj_T[3:6, 3:6] = R_mat
        return adj_T

    def wrench_trans(self, torques, forces, T):
        """
        Transforms the input wrench (torques, forces) with T.
        Outputs transformed wrench (torques, forces)
        """
        wrench_in_A = np.hstack((torques, forces))
        wrench_in_B = self.adjoint(T).T @ wrench_in_A
        return wrench_in_B[:3], wrench_in_B[3:]
    
    def updateWrench(self, current_tcp_pose, Tau_insert, F_insert):
        transform = self.get_base_tcp_transform(current_tcp_pose)
        mu, f = self.wrench_trans(Tau_insert, F_insert, transform)
        t = transform[0:3, 3]
        rvec = R.from_matrix(transform[0:3, 0:3]).as_rotvec()

        #return wrench and robot task_frame
        return np.hstack((f, mu)), np.hstack((t,rvec))
    def move_until_contact_force_based(self,
                                  speed_vec,
                                  force_threshold=8.0,
                                  axis=2,
                                  timeout=100.0,
                                  rate=10):
   
       
        self.robot_rtde.zeroFtSensor()
        print("start to contact")
        rate_dt = 1.0 / rate
        start_time = time.time()
        while time.time() - start_time < timeout:
            self.robot_rtde.speedL(speed_vec, 0.1, 0.1)
            force = self.robot_rtde.getActualTCPForce()
            print(f"[Contact] current axis {axis} force = {force[axis]:.2f} N")
            if abs(force[axis]) > force_threshold:
                print(f"[Contact]stat:{force[axis]:.2f} N > thres {force_threshold} N")
                break
            time.sleep(rate_dt)
        else:
            
            self.robot_rtde.speedStop()
            return False
        
        self.robot_rtde.speedStop()
        time.sleep(0.2)
        return True
        
    def reset_vars(self):
        self.action_index = 0
        self.is_task_done = False
        if self.initialized:
            if self.task_thread:
                self.task_thread.join()
                self.task_thread = None
        self.initialized = False

    def custom_reset(self):
            self.reset_vars()
class OgnInsertScaleDrum:
    """
         Node for insertion of the Scale Drum
    """
    @staticmethod
    def internal_state():
        return OgnInsertScaleDrumInternalState()
    
    @staticmethod
    def compute(db) -> bool:
        try:
            state = db.internal_state

            if not db.inputs.runInSimulation:
                if not state.initialized and not state.is_task_done:
                    indicate_node_exec_running(db.node)
                    state.initialize_task(db)
                    # Check preconditions
                    if not state.check_preconditions(db):
                        indicate_node_exec_ended(db.node)
                        return False

                    # Perform task
                    state.task_thread.start()
                    state.initialized = True
            else:
                state.is_task_done = True

            # Check if the task has finished
            if state.is_task_done:
                # Reset variables to allow running again
                # state.reset_vars()

                indicate_node_exec_ended(db.node)

                # Evaluate task
                success = state.evaluate_task(db)
                if success:
                    # signal that we are done, so that execution flow continues downstream.
                    db.outputs.success = og.ExecutionAttributeState.LATENT_FINISH
                    return True
                else:
                    return False
        
        except Exception as error:
            db.log_warn(str(error))
            return False

    
        # save the current node as it performs some asynchronous operation
        db.outputs.success = og.ExecutionAttributeState.LATENT_PUSH
        return True
    @staticmethod
    def release(node):
        try:
            state =  OgnInsertScaleDrumDatabase.per_node_internal_state(node)
        except Exception:
            state = None
            pass

        if state is not None:
            state.reset()