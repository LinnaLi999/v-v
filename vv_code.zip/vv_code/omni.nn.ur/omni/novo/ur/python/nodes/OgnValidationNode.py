from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core_nodes import BaseResetNode
from omni.sdu.ur.ogn.OgnValidationNodeDatabase import OgnValidationNodeDatabase
from omni.sdu.core.utilities.utils import indicate_node_exec_running

from scipy.spatial.transform import Rotation as R
from fastdtw import fastdtw
import numpy as np
import matplotlib.pyplot as plt
import re
import time
from datetime import datetime

# ---------- Transformation Utilities ----------
def make_transform_matrix(translation, rpy=None, rotation_matrix=None):
    T = np.eye(4)
    T[:3, 3] = translation
    if rotation_matrix is not None:
        T[:3, :3] = rotation_matrix
    elif rpy is not None:
        T[:3, :3] = R.from_euler("xyz", rpy).as_matrix()
    return T

def joint_transform(rpy, xyz, axis, theta):
    T = make_transform_matrix(xyz, rpy)
    R_axis = R.from_rotvec(theta * np.array(axis)).as_matrix()
    T_rot = np.eye(4)
    T_rot[:3, :3] = R_axis
    return T @ T_rot

def compute_tcp_world(joint_q, joints, T_w2b, T_b2bl, T_w3_t0):
    T = np.eye(4)
    for i in range(6):
        joints[i]["theta"] = joint_q[i]
        T = T @ joint_transform(joints[i]["rpy"], joints[i]["xyz"], joints[i]["axis"], joints[i]["theta"])
    T_tcp = T @ T_w3_t0
    return (T_w2b @ T_b2bl @ T_tcp)[:3, 3]

def joints_to_tcp_trajectory(joint_qs, joints, T_w2b, T_b2bl, T_w3_t0):
    return np.array([compute_tcp_world(q, joints, T_w2b, T_b2bl, T_w3_t0) for q in joint_qs])

# ---------- Log Parsing ----------
def extract_joint_data(file_path):
    sim_data, real_data = [], []
    with open(file_path, 'r') as f:
        for line in f:
            if "sim_joint_q:" in line:
                values = [float(x) for x in line.split("sim_joint_q:")[1].strip().split(",")[:6]]
                sim_data.append(values)
            elif "real_joint_q:" in line:
                values = [float(x) for x in line.split("real_joint_q:")[1].strip().split(",")[:6]]
                real_data.append(values)
    return np.array(sim_data), np.array(real_data)

def extract_real_and_sim_tcp(log_path):
    real_list, sim_list = [], []
    with open(log_path, 'r') as f:
        lines = f.readlines()
    i = 0
    while i < len(lines) - 2:
        if "sim tcp trans:" in lines[i] and "sim tcp quat:" in lines[i+1] and "real tcp:" in lines[i+2]:
            try:
                trans = [float(x) for x in lines[i].split("sim tcp trans:")[1].strip().split(',')]
                quat_line = lines[i+1].split("sim tcp quat:")[1].strip()
                quat_vals = re.findall(r"[\w]=([-0-9.eE]+)", quat_line)
                if len(quat_vals) != 4:
                    i += 1
                    continue
                w, x, y, z = map(float, quat_vals)
                sim_quat = [x, y, z, w]
                sim_list.append(trans + sim_quat)
                real = [float(x.strip()) for x in lines[i+2].split("real tcp:")[1].strip().split(',')]
                if len(real) == 6:
                    real_list.append(real)
            except:
                pass
        i += 1
    return np.array(real_list), np.array(sim_list)

# ---------- Alignment ----------
def align_joint_by_tcp(sim_joint_q, real_joint_q, joints, T_w2b, T_b2bl, T_w3_t0):
    sim_last_tcp = compute_tcp_world(sim_joint_q[-1], joints, T_w2b, T_b2bl, T_w3_t0)
    real_tcp_positions = joints_to_tcp_trajectory(real_joint_q, joints, T_w2b, T_b2bl, T_w3_t0)
    distances = np.linalg.norm(real_tcp_positions - sim_last_tcp, axis=1)
    cut_index = np.argmin(distances)
    real_joint_q = real_joint_q[:cut_index + 1]
    sim_tcp = joints_to_tcp_trajectory(sim_joint_q, joints, T_w2b, T_b2bl, T_w3_t0)
    real_tcp = joints_to_tcp_trajectory(real_joint_q, joints, T_w2b, T_b2bl, T_w3_t0)
    _, path = fastdtw(sim_tcp, real_tcp, radius=5)
    sim_to_real = {}
    for i, j in path:
        if i not in sim_to_real:
            sim_to_real[i] = j
    sim_aligned = np.array([sim_joint_q[i] for i in sorted(sim_to_real.keys())])
    real_aligned = np.array([real_joint_q[sim_to_real[i]] for i in sorted(sim_to_real.keys())])
    return sim_aligned, real_aligned

def align_joint(sim_joint_q, real_joint_q, joints, T_w2b, T_b2bl, T_w3_t0):
    distances = np.linalg.norm(real_joint_q - sim_joint_q[-1], axis=1)
    cut_index = np.argmin(distances)
    real_joint_q = real_joint_q[:cut_index + 1]
    _, path = fastdtw(sim_joint_q, real_joint_q, radius=5)
    sim_to_real = {}
    for i, j in path:
        if i not in sim_to_real:
            sim_to_real[i] = j
    sim_aligned = np.array([sim_joint_q[i] for i in sorted(sim_to_real.keys())])
    real_aligned = np.array([real_joint_q[sim_to_real[i]] for i in sorted(sim_to_real.keys())])
    return sim_aligned, real_aligned

def convert_real_tcp_to_sim(tcp, T_w2b, T_b2bl):
    pos = np.array(tcp[:3])
    rotvec = tcp[3:]
    r_real = R.from_rotvec(rotvec)
    T_real = make_transform_matrix(pos, rotation_matrix=r_real.as_matrix())
    T_sim = T_w2b @ T_b2bl @ T_real
    sim_pos = T_sim[:3, 3]
    sim_quat = R.from_matrix(T_sim[:3, :3]).as_quat()
    return np.concatenate([sim_pos, sim_quat])

def pose_distance(p1, p2, w=0.5):
    pos1, quat1 = p1[:3], p1[3:]
    pos2, quat2 = p2[:3], p2[3:]
    pos_diff = np.linalg.norm(pos1 - pos2)
    rot1 = R.from_quat(quat1)
    rot2 = R.from_quat(quat2)
    relative_rot = rot1.inv() * rot2
    angle_diff = relative_rot.magnitude()
    return pos_diff + w * angle_diff

def align_tcp_by_dtw(real_tcp_7d, sim_tcp_7d):
    _, path = fastdtw(sim_tcp_7d, real_tcp_7d, dist=pose_distance, radius=5)
    sim_aligned = np.array([sim_tcp_7d[i] for i, j in path])
    real_aligned = np.array([real_tcp_7d[j] for i, j in path])
    return sim_aligned, real_aligned

# ---------- Error Evaluation ----------
def compare_joints(sim_aligned, real_aligned, log_path):
    joint_diff = np.abs(sim_aligned - real_aligned)
    mean_diff_rad = np.mean(joint_diff, axis=0)
    mean_diff_deg = np.degrees(mean_diff_rad)
    max_diff_rad = np.max(joint_diff, axis=0)
    max_diff_deg = np.degrees(max_diff_rad)
    with open(log_path, 'w') as f:
        f.write("==== Joint Mean Difference After DTW ====\n")
        f.write("Joint\tMean Error (rad)\tMean Error (deg)\tMax Error (rad)\tMax Error (deg)\n")
        for i in range(6):
            f.write(f"joint_{i+1}\t{mean_diff_rad[i]:.6f}\t\t{mean_diff_deg[i]:.2f}\t\t{max_diff_rad[i]:.6f}\t\t{max_diff_deg[i]:.2f}\n")

def plot_3d_tcp_trajectories(sim_aligned, real_aligned, save_path):
    sim_pos = sim_aligned[:, :3]
    real_pos = real_aligned[:, :3]
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(real_pos[:, 0], real_pos[:, 1], real_pos[:, 2], label="Real TCP", color='blue')
    ax.plot(sim_pos[:, 0], sim_pos[:, 1], sim_pos[:, 2], label="Sim TCP", color='orange')
    ax.scatter(real_pos[0, 0], real_pos[0, 1], real_pos[0, 2], color='navy', marker='o', label='Start - Real')
    ax.scatter(sim_pos[0, 0], sim_pos[0, 1], sim_pos[0, 2], color='red', marker='o', label='Start - Sim')
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")
    ax.set_title("3D TCP Trajectories Aligned by DTW")
    ax.invert_yaxis()
    ax.invert_xaxis()
    ax.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()

def analyze_tcp_error_rmse(sim_aligned, real_aligned):
    sim_pos = sim_aligned[:, :3]
    sim_quat = sim_aligned[:, 3:]
    real_pos = real_aligned[:, :3]
    real_quat = real_aligned[:, 3:]
    pos_error = sim_pos - real_pos
    rmse_xyz = np.sqrt(np.mean(pos_error ** 2, axis=0))
    rmse_euclidean = np.sqrt(np.mean(np.linalg.norm(pos_error, axis=1) ** 2))
    sim_euler = R.from_quat(sim_quat).as_euler('xyz', degrees=True)
    real_euler = R.from_quat(real_quat).as_euler('xyz', degrees=True)
    angle_error = (sim_euler - real_euler + 180) % 360 - 180
    rmse_rpy_deg = np.sqrt(np.mean(angle_error ** 2, axis=0))
    return rmse_xyz, rmse_euclidean, rmse_rpy_deg

# ---------- OmniGraph Node ----------
class OgnValidationNodeInternalState(BaseResetNode):
    def __init__(self):
        self.initialized = False
        self.last_eval_time = time.time()
        self.eval_interval = 45
        self.world = None
        super().__init__(initialize=False)

class OgnValidationNode:
    @staticmethod
    def internal_state():
        return OgnValidationNodeInternalState()

    @staticmethod
    def compute(db) -> bool:
        state = db.per_instance_state
        if not state.initialized:
            indicate_node_exec_running(db.node)
            state.world = World.instance()
            state.initialized = True

        current_time = time.time()
        if current_time - state.last_eval_time >= state.eval_interval:
            state.last_eval_time = current_time

            joints = [
                {"rpy": [0, 0, 0], "xyz": [0, 0, 0.1625], "axis": [0, 0, 1]},
                {"rpy": [np.pi/2, 0, 0], "xyz": [0, 0, 0], "axis": [0, 0, 1]},
                {"rpy": [0, 0, 0], "xyz": [-0.425, 0, 0], "axis": [0, 0, 1]},
                {"rpy": [0, 0, 0], "xyz": [-0.3922, 0, 0.1333], "axis": [0, 0, 1]},
                {"rpy": [np.pi/2, 0, 0], "xyz": [0, -0.0997, 0], "axis": [0, 0, 1]},
                {"rpy": [np.pi/2, np.pi, np.pi], "xyz": [0, 0.0996, 0], "axis": [0, 0, 1]},
            ]

            T_w2b = make_transform_matrix([0.94138, -0.36988, -0.12539])
            T_b2bl = make_transform_matrix([0, 0, 0], rpy=[0, 0, np.pi])
            T_w3_t0 = make_transform_matrix([0, 0, 0.195])

            file_path = "/home/nyll/Desktop/project/log/longc/log_17.txt"
            sim_data, real_data = extract_joint_data(file_path)
            sim_aligned, real_aligned = align_joint(sim_data, real_data, joints, T_w2b, T_b2bl, T_w3_t0)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_path = f"/home/nyll/Desktop/project/sdu/log/longc/joint_error_{timestamp}.txt"
            fig_path = f"/home/nyll/Desktop/project/sdu/log/longc/tcp_traj_plot_{timestamp}.png"

            compare_joints(sim_aligned, real_aligned, log_path)

            # --- New TCP plot from log ---
            real_tcp_6d, sim_tcp_7d = extract_real_and_sim_tcp(file_path)
            real_tcp_7d = np.array([convert_real_tcp_to_sim(tcp, T_w2b, T_b2bl) for tcp in real_tcp_6d])
            sim_aligned_tcp, real_aligned_tcp = align_tcp_by_dtw(real_tcp_7d, sim_tcp_7d)

            plot_3d_tcp_trajectories(sim_aligned_tcp, real_aligned_tcp, fig_path)
            rmse_xyz, rmse_euclidean, rmse_rpy = analyze_tcp_error_rmse(sim_aligned_tcp, real_aligned_tcp)

            print(f"[{timestamp}] ✅ Joint & TCP evaluation complete.\nLog: {log_path}")

        return True

    @staticmethod
    def release(node):
        try:
            state = OgnValidationNodeDatabase.get_internal_state(node)
        except Exception:
            return
        if state:
            state.initialized = False
