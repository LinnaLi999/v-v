from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core_nodes import BaseResetNode
from omni.isaac.core.prims.xform_prim import XFormPrim
from omni.isaac.core.utils.prims import is_prim_path_valid, get_prim_at_path
from omni.sdu.core.utilities.utils import get_pose_in_reference_frame, get_robot_pose_from_frame, get_pose_from_frame_in_world, get_isaac_pose_from_ur_pose
import threading
import copy
from omni.graph.action import get_interface
from omni.sdu.ur.ogn.OgnRecordData2NodeDatabase import OgnRecordData2NodeDatabase
from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended
from scipy.spatial.transform import Rotation as R
import numpy as np
import time
import omni.kit.commands
from pxr import Sdf, Usd
import logging
import queue
from logging.handlers import QueueHandler, QueueListener
from fastdtw import fastdtw
import matplotlib.pyplot as plt

log_queue = queue.Queue()
logger = logging.getLogger("simulation_logger2")
logger.setLevel(logging.INFO)
if logger.hasHandlers():
    logger.handlers.clear()
file_handler = logging.FileHandler('/home/nyll/Desktop/project/log/log_77.txt', mode='a')
file_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
queue_handler = QueueHandler(log_queue)
logger.addHandler(queue_handler)
queue_listener = QueueListener(log_queue, file_handler, respect_handler_level=True)
queue_listener.start()

log_buffer = []
LOG_FLUSH_INTERVAL = 1

def queue_log(message):
    global log_buffer
    log_buffer.append(message)
    if len(log_buffer) >= LOG_FLUSH_INTERVAL:
        flush_logs()

def flush_logs():
    global log_buffer
    for msg in log_buffer:
        logger.info(msg)
    log_buffer.clear()

def stop_logging():
    global logging_enabled
    logging_enabled = False
    flush_logs()
    print("stop recording data")

def make_transform_matrix(translation, rpy=None, rotation_matrix=None):
    T = np.eye(4)
    T[:3, 3] = translation
    if rotation_matrix is not None:
        T[:3, :3] = rotation_matrix
    elif rpy is not None:
        T[:3, :3] = R.from_euler("xyz", rpy).as_matrix()
    return T

def trans(x, y, z):
    return make_transform_matrix([x, y, z])

def joint_transform(rpy, xyz, axis, theta):
    T = make_transform_matrix(xyz, rpy)
    R_axis = R.from_rotvec(theta * np.array(axis)).as_matrix()
    T_rot = np.eye(4)
    T_rot[:3, :3] = R_axis
    return T @ T_rot

def compute_tcp_world(joint_q, joints, T_w2b, T_b2bl, T_w3_t0):
    T = np.eye(4)
    for i in range(6):
        joints[i]["theta"] = joint_q[i]
        T = T @ joint_transform(joints[i]["rpy"], joints[i]["xyz"], joints[i]["axis"], joints[i]["theta"])
    T_tcp = T @ T_w3_t0
    return (T_w2b @ T_b2bl @ T_tcp)[:3, 3]

def extract_joint_data(file_path):
    sim_data, real_data = [], []
    with open(file_path, 'r') as f:
        for line in f:
            if "sim_joint_q:" in line:
                values = [float(x) for x in line.split("sim_joint_q:")[1].strip().split(",")[:6]]
                sim_data.append(values)
            elif "real_joint_q:" in line:
                values = [float(x) for x in line.split("real_joint_q:")[1].strip().split(",")[:6]]
                real_data.append(values)
    return np.array(sim_data), np.array(real_data)

def align_sim_to_real(sim, real):
    dist_fn = lambda x, y: np.linalg.norm(x - y)
    _, path = fastdtw(sim, real, dist=dist_fn)
    sim_aligned = np.array([sim[i] for i, j in path])
    return sim_aligned

def plot_ee_trajectories(sim_data, real_data, joints, T_w2b, T_b2bl, T_w3_t0):
    sim_aligned = align_sim_to_real(sim_data, real_data)
    ee_sim = np.array([compute_tcp_world(q, joints, T_w2b, T_b2bl, T_w3_t0) for q in sim_aligned])
    ee_real = np.array([compute_tcp_world(q, joints, T_w2b, T_b2bl, T_w3_t0) for q in real_data])

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(ee_real[:, 0], ee_real[:, 1], ee_real[:, 2], label="Real Trajectory", color='blue')
    ax.plot(ee_sim[:, 0], ee_sim[:, 1], ee_sim[:, 2], label="Sim Trajectory", color='orange')

    ax.scatter(ee_real[0, 0], ee_real[0, 1], ee_real[0, 2], color='blue', marker='o', s=60, label='Start - Real')
    ax.scatter(ee_sim[0, 0], ee_sim[0, 1], ee_sim[0, 2], color='orange', marker='o', s=60, label='Start - Sim')
    ax.scatter(ee_real[-1, 0], ee_real[-1, 1], ee_real[-1, 2], color='navy', marker='X', s=80, label='End - Real')
    ax.scatter(ee_sim[-1, 0], ee_sim[-1, 1], ee_sim[-1, 2], color='red', marker='X', s=80, label='End - Sim')

    ax.set_title("3D End-Effector Trajectory After DTW Alignment")
    ax.set_xlabel("X [m]")
    ax.set_ylabel("Y [m]")
    ax.set_zlabel("Z [m]")
    ax.legend()
    ax.invert_yaxis()
    ax.invert_xaxis()
    plt.tight_layout()
    plt.savefig("/home/nyll/Desktop/project/log/traj_plot.png", dpi=300)

# Replace original trajectory plotting in the node logic with a call to plot_ee_trajectories where appropriate
