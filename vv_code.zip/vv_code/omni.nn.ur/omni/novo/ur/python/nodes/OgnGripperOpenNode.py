from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core_nodes import BaseResetNode
import requests
import threading
from omni.sdu.ur.ogn.OgnGripperOpenNodeDatabase import OgnGripperOpenNodeDatabase
from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended
from omni.sdu.ur.scripts.robotiq_gripper import RobotiqGripper
from omni.isaac.core.prims.xform_prim import XFormPrim
import os
class Gripper(XFormPrim, RobotiqGripper):
   def __init__(self, ip: str, prim_path: str, name: str):
       self._ip = ip
       self._port = 63352  # Robotiq UR Cap port
       RobotiqGripper.__init__(self)
       self.connect(self._ip, self._port)
       XFormPrim.__init__(self, prim_path=prim_path, name=name)
   def initialize(self, physics_sim_view=None) -> None:
       """To be called before using this class after a reset of the world"""
       XFormPrim.initialize(self, physics_sim_view=physics_sim_view)
       return
   def post_reset(self) -> None:
       return
class OgnGripperOpenInternalState(BaseResetNode):

    def __init__(self):
        self.initialized = False
        self.task_thread = None
        self.is_task_done = False
        self.gripper_path = None
        self.gripper_ip = None
        self.gripper = None

        super().__init__(initialize=False)

    def initialize_task(self, db):
        # attempt to get specified gripper from World
        self.world = World.instance()
        # self.gripper = self.world.scene.get_object(db.inputs.gripper)
        obj_name = os.path.basename(self.gripper_path) + '_real'
        # self.gripper = Gripper(ip=self.gripper_ip, prim_path="/World/" + obj_name, name=obj_name)
        self.gripper = self.world.scene.get_object(obj_name )
        # self.robot_rtde = self.world.scene.get_object(db.inputs.urRobot + '_rtde')
        if self.gripper is None:
            db.log_error("The specified gripper does not exist!")
        else:
            print("Got gripper: ", db.inputs.gripper)

        
        self.task_thread = threading.Thread(target=self.perform_task, args=(db,), daemon=False)

    def perform_task(self, db):
        """
        Perform task or skill in a separate thread to avoid freezing the main UI thread.

        Parameters:
            db : internal node data

        """
        # open the gripper
        if self.gripper:
            db.log_info("Opening gripper "+db.inputs.gripper)
            # self.gripper.move_and_wait_for_pos(self.gripper.get_open_position(), db.inputs.speed, db.inputs.force)
            self.gripper.move_and_wait_for_pos(db.inputs.position, db.inputs.speed, db.inputs.force)
            db.log_info("Done opening gripper "+db.inputs.gripper)
        else:
            db.log_warn("No gripper to actuate. The node was not passed a gripper")

        self.is_task_done = True

    def evaluate_task(self, db) -> bool:
        """
        Evaluate and if possible verify whether the task or skill was successfully performed. If this task
        is performed successfully and it can verified that it was done correctly this function returns True.
        If that is not the case False is returned.

        Parameters:
            db : internal node data

        Returns:
            success(bool) : True if preconditions are met, False otherwise
        """
        success = True
        return success

    def check_preconditions(self, db) -> bool:
        """
        Check any preconditions for performing this task or skill, if a precondition
        is not met False should be returned, other this function returns True by default.

        Parameters:
            db : internal node data

        Returns:
            preconditions_met(bool) : True if preconditions are met, False otherwise
        """
        preconditions_met = True
            
        if not db.inputs.gripper:
            db.log_warn("Please specify a gripper to use")
            preconditions_met = False
        
        return preconditions_met
    
    def reset_vars(self):
        self.action_index = 0
        self.is_task_done = False
        if self.initialized:
           if self.task_thread:
               self.task_thread.join()
               self.task_thread = None
        self.initialized = False

    def custom_reset(self):
        self.reset_vars()
        


class OgnGripperOpenNode:
    """
    node for closing a gripper
    """
    
    @staticmethod
    def internal_state():
        return OgnGripperOpenInternalState()
    
    @staticmethod
    def compute(db) -> bool:
        try:
            state = db.internal_state
            state.gripper_path = db.inputs.gripper   
            state.gripper_ip = db.inputs.gripperIP 
            if not state.initialized:
                indicate_node_exec_running(db.node)

                state.initialize_task(db)
                # Check preconditions
                if not state.check_preconditions(db):
                    indicate_node_exec_ended(db.node)
                    return False

                # Perform task
                state.task_thread.start()
                state.initialized = True

            if state.initialized and state.is_task_done:
            # Evaluate task
                # print("state",state.is_task_done)
                db.outputs.execOut = og.ExecutionAttributeState.ENABLED

                # get_interface().set_execution_enabled("outputs:success")
                return True
           
        
        except Exception as error:
            db.log_warn(str(error))
            return False
        return True

    @staticmethod
    def release(node):
        try:
            state = OgnGripperOpenNodeDatabase.per_node_internal_state(node)
        except Exception:
            state = None
            pass

        if state is not None:
            state.reset()