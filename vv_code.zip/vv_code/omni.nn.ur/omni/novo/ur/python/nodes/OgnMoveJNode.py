import copy
import math
import threading
import omni.graph.core as og
from omni.isaac.core import World
from omni.isaac.core_nodes import BaseResetNode
from omni.graph.action import get_interface
from pxr import Sdf, Usd
from omni.sdu.ur.ogn.OgnMoveJNodeDatabase import OgnMoveJNodeDatabase
from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended
import time
import omni.kit.commands
from omni.isaac.core.utils.prims import get_prim_children, get_prim_at_path
from pxr import UsdGeom
class OgnMoveJInternalState(BaseResetNode):
    def __init__(self):
        self.initialized = False
        self.task_thread = None
        self.is_task_done = False
        self.robot = None
        self.robot_rtde = None
        self.action_index = 0
        self.velocity_used = 0.0
        self.world = None
        self.articulation_traj = None
        self.action_sequence = None
        self.velocity = 0.0
        self.acceleration = 0.0
        self.finish = False
        self.active_path =None
        self.initial_z =0
        super().__init__(initialize=False)

    def initialize_task(self, db):
        self.world = World.instance()
        if self.world is not None:
            if db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both":
                # attempt to get simulated robot object from World
                self.robot = self.world.scene.get_object(
                    db.inputs.urRobot + "_articulation"
                )
                if self.robot is None:
                    db.log_warn(
                        "The node could not initialize the simulated robot, to use for executing the task."
                    )
                else:
                    self.robot.initialize()

            if db.inputs.executionMode == "Real" or db.inputs.executionMode == "Both":
                # attempt to get real robot object from World
                self.robot_rtde = self.world.scene.get_object(
                    db.inputs.urRobot + "_physical"
                )  # Notice! the _physical suffix is appended automatically here
                if self.robot_rtde is None:
                    db.log_warn(
                        "The node could not initialize the real rtde robot, to use for executing the task."
                    )

                self.task_thread = threading.Thread(
                    target=self.perform_task, args=(db,), daemon=False
                )

            if db.inputs.pose:
                self.pose_db = self.world.scene.get_object("pose_db")
                if self.pose_db is None:
                    db.log_warn("The node found no pose database!")
                else:
                    self.joint_pose = self.pose_db.get_pose_from_db(db, db.inputs.pose)
                    if not self.joint_pose:
                        db.log_error("Could not retrieve joint pose from database!")
                        return False
                    elif len(self.joint_pose) != 6:
                        db.log_error(
                            "Joint pose is not a valid pose! length is incorrect."
                        )
                        return False
            else:
                # Assume manually entered joint pose
                self.joint_pose = [
                    math.radians(db.inputs.q0),
                    math.radians(db.inputs.q1),
                    math.radians(db.inputs.q2),
                    math.radians(db.inputs.q3),
                    math.radians(db.inputs.q4),
                    math.radians(db.inputs.q5),
                ]
            
            if db.inputs.velocity:
                self.velocity = db.inputs.velocity
            else:
                db.log_warn("No velocity specified, using default speed for the moveJ (speed = 1.05)")
                self.velocity = 1.05
            
            if db.inputs.acceleration:
                self.acceleration = db.inputs.acceleration
            else:
                db.log_warn("No acceleration specified, using default acceleration for the moveJ (acceleration = 1.4)")
                self.acceleration = 1.4
                
        else:
            db.log_warn(
                "A world with a scene has not been defined in Omniverse. Did you initialize the robot before calling this node?"
            )

    def perform_task(self, db):
        """
        Perform task or skill in a separate thread to avoid freezing the main UI thread.

        Parameters:
            db : internal node data

        """

        # perform moveJ on the real robot using the provided pose
        if self.robot_rtde:
            if db.inputs.pose:
                db.log_info(
                    "Moving "

                    + str(db.inputs.pose)
                    + ")"
                    + str(self.joint_pose)
                )
            else:
                db.log_info(
                    "Moving " + db.inputs.urRobot + " to: " + str(self.joint_pose)
                )
            start_time = time.time()
            self.robot_rtde.moveJ(self.joint_pose, self.velocity, self.acceleration)
            end_time = time.time()

            duration_real = end_time -start_time
            # with open ('/home/nyll/Desktop/project/sdu/log/simulation_log32.txt', "a") as f:
            #     f.write(f"{duration_real:.3f}")

            db.log_info("Done moving " + db.inputs.urRobot)

            self.is_task_done = True

    def evaluate_task(self, db) -> bool:
        """
        Evaluate and if possible verify whether the task or skill was successfully performed. If this task
        is performed successfully and it can verified that it was done correctly this function returns True.
        If that is not the case False is returned.

        Parameters:
            db : internal node data

        Returns:
            success(bool) : True if preconditions are met, False otherwise
        """
        success = True
        return success

    def check_preconditions(self, db) -> bool:
        """
        Check any preconditions for performing this task or skill, if a precondition
        is not met False should be returned, other this function returns True by default.

        Parameters:
            db : internal node data

        Returns:
            preconditions_met(bool) : True if preconditions are met, False otherwise
        """
        preconditions_met = True

        if not db.inputs.urRobot:
            db.log_warn("Please specify a UR robot to use for this movement!")
            preconditions_met = False

        return preconditions_met

    def reset_vars(self):
        self.action_index = 0
        self.is_task_done = False
        self.finish = False
        if self.task_thread:
            self.task_thread.join()
            self.task_thread = None

    def custom_reset(self):
        self.reset_vars()
        self.initialized = False
        

    def make_interpolation(self, db):
        current_q = self.robot.get_joint_positions()[:6]
        target_q = self.joint_pose
        self.articulation_traj = self.robot.get_interpolated_traj_joint_space(
            current_q, target_q, db.inputs.velocity,db.inputs.acceleration
        )
        print("Trajectory duration: ", self.articulation_traj.get_trajectory_duration())
        duration_sim = self.articulation_traj.get_trajectory_duration()

        self.action_sequence = self.articulation_traj.get_action_sequence()
    def get_active_scale_drum(self):
    
            parent_path="/World/Scale_drum"
            height_threshold=0.009
            parent_prim = get_prim_at_path(parent_path)
            children = get_prim_children(parent_prim)
            for prim in children:
                # prim_path = str(prim.GetPath())
                z = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0).ExtractTranslation()[2]
                if z > height_threshold:
                    path = str(prim.GetPath())
                    print(f"current object: {path}, initial height: {z:.4f}m")

    def check_if_drum_descended(self,active_path, initial_z, descend_threshold=0.005):

        if active_path is None:
            print("invalid")
            return False
        prim = get_prim_at_path(active_path)
        z_now = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0).ExtractTranslation()[2]
        dz = initial_z - z_now
        print(f"📏 {active_path} height devation: {dz:.4f}m")
        # if dz >= descend_threshold:
        #     self.descend = True
        return dz > descend_threshold

class OgnMoveJNode:
    """
    node for controlling a UR robot.
    """

    @staticmethod
    def internal_state():
        return OgnMoveJInternalState()

    @staticmethod
    def compute(db) -> bool:
        state = db.per_instance_state

        if not state.initialized:
            indicate_node_exec_running(db.node)

            # Initialize task
            state.initialize_task(db)

            # Check preconditions
            if not state.check_preconditions(db):
                return False

            if db.inputs.pose:
                print("Performing MoveJ to: " + str(db.inputs.pose))
            else:
                print(
                    "Performing MoveJ to: "
                    + str(db.inputs.q0)
                    + ", "
                    + str(db.inputs.q1)
                    + ", "
                    + str(db.inputs.q2)
                    + ", "
                    + str(db.inputs.q3)
                    + ", "
                    + str(db.inputs.q4)
                    + ", "
                    + str(db.inputs.q5)
                )

            if db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both":
                if db.inputs.sim_step == True:
                   
                    omni.kit.commands.execute('ChangeProperty',
                        prop_path=Sdf.Path('/physicsScene.physxScene:timeStepsPerSecond'),
                        value=60,
                        prev=300,
                        target_layer=Sdf.Find('file:/home/nyll/Desktop/project/sdu/c207.usd'),
                        usd_context_name=omni.usd.get_context().get_stage())
                # if db.inputs.detect_height == True:
                #     state.get_active_scale_drum()
                #     state.active_path, state.initial_z = state.get_active_scale_drum()
                if state.robot is not None:
                    state.make_interpolation(db)

            if db.inputs.executionMode == "Real" or db.inputs.executionMode == "Both":
                # Perform task
                state.task_thread.start()

            state.initialized = True
            
        if state.initialized and (db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both"):
            if state.action_sequence is not None:
                # perform next action in trajectory if any left
                #and not state.check_if_drum_descended(state.active_path, state.initial_z)
                if state.action_index < len(state.action_sequence) :
                    state.robot.apply_articulation_action(state.action_sequence[state.action_index])
                    state.action_index += 1

                else:
                    indicate_node_exec_ended(db.node)
                    state.is_task_done = True

        db.outputs.finish = state.finish
        # Check if the task has finished
        if state.initialized :
            if state.is_task_done: 
                # sim_tcp = state.robot.get_tcp().translation
                # print("sim tcp",sim_tcp)
            # Evaluate task
                success = state.evaluate_task(db)
                if success:
                    # signal that we are done, so that execution flow continues downstream.
                    get_interface().set_execution_enabled("outputs:success")
                    if db.inputs.sim_record :
                        state.finish = False
                        db.outputs.finish = state.finish  
                    return True
                else:
                    
                    get_interface().set_execution_enabled("outputs:error")
                    return False
            else:
                if db.inputs.sim_record :
                        state.finish = True
                        db.outputs.finish = state.finish 

        # save the current node as it performs some asynchronous operation
        return True

    @staticmethod
    def release(node):
        try:
            state = OgnMoveJNodeDatabase.get_internal_state(node)
        except Exception:
            state = None
            pass

        if state is not None:
            state.reset()
