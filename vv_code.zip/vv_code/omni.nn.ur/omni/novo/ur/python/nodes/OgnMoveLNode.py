from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core_nodes import BaseResetNode
from omni.isaac.core.prims.xform_prim import XFormPrim
from omni.isaac.core.utils.prims import is_prim_path_valid
from omni.isaac.core.utils.prims import get_prim_at_path
from omni.sdu.core.utilities.utils import get_pose_in_reference_frame, get_robot_pose_from_frame, get_pose_from_frame_in_world, get_isaac_pose_from_ur_pose
import threading
import copy
from omni.graph.action import get_interface
from omni.sdu.ur.ogn.OgnMoveLNodeDatabase import OgnMoveLNodeDatabase
from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended
from scipy.spatial.transform import Rotation as R
import numpy as np
import time
import omni.kit.commands
from pxr import Sdf, Usd
import logging
import queue
from logging.handlers import QueueHandler, QueueListener
log_queue = queue.Queue()
logger = logging.getLogger("simulation_logger")
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler('/home/nyll/Desktop/project/log/loga.txt', mode='a')
file_handler.setLevel(logging.INFO)  
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
queue_handler = QueueHandler(log_queue)
logger.addHandler(queue_handler)
queue_listener = QueueListener(log_queue, file_handler, respect_handler_level=True)
queue_listener.start()
log_buffer = []
LOG_FLUSH_INTERVAL = 10
def queue_log(message):
   global log_buffer
   log_buffer.append(message)
   if len(log_buffer) >= LOG_FLUSH_INTERVAL:
       flush_logs()  
def flush_logs():
   global log_buffer
   for msg in log_buffer:
       logger.info(msg) 
   log_buffer.clear()
def cartesian_to_transform(x, y, z, rx, ry, rz):
    
    Rx = np.array([
        [1, 0, 0],
        [0, np.cos(rx), -np.sin(rx)],
        [0, np.sin(rx), np.cos(rx)]
    ])
    
    Ry = np.array([
        [np.cos(ry), 0, np.sin(ry)],
        [0, 1, 0],
        [-np.sin(ry), 0, np.cos(ry)]
    ])
    
    Rz = np.array([
        [np.cos(rz), -np.sin(rz), 0],
        [np.sin(rz), np.cos(rz), 0],
        [0, 0, 1]
    ])
    # R = Rz * Ry * Rx
    R = Rz.dot(Ry).dot(Rx)
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = [x, y, z]
    return T
def transform_to_cartesian(T):

    # 提取位置
    x = T[0, 3]
    y = T[1, 3]
    z = T[2, 3]
    # 从旋转矩阵提取欧拉角 (XYZ顺序)
    R = T[0:3, 0:3]
    # 计算欧拉角
    sy = np.sqrt(R[2,1]**2 + R[2,2]**2)
    if sy > 1e-6:
        rx = np.arctan2(-R[1,2], R[2,2])
        ry = np.arctan2(R[0,2], sy)
        rz = np.arctan2(-R[0,1], R[0,0])
    else:  # Gimbal lock
        rx = np.arctan2(-R[1,2], R[2,2])
        ry = np.arctan2(R[0,2], sy)
        rz = 0
    return np.array([x, y, z, rx, ry, rz])

class OgnMoveLInternalState(BaseResetNode):

    def __init__(self):
        self.initialized = False
        self.task_thread = None
        self.task_done = False
        self.task_real_done = False
        self.frame_path = None
        self.robot = None
        self.robot_rtde = None
        self.frame_prim = None
        self.action_index = 0
        self.velocity_used = 0.0
        self.world = None
        self.articulation_traj = None
        self.action_sequence = None 
        self.cartesian_pose_sim = None
        self.cartesian_pose_real = None
        self.iteration = 1
        self.sim_start_time = None
        self.sim_end_time = None
        self.is_recording = False
        self.finish= False
        self.real_finish = False
        self.sim_logged = False
        super().__init__(initialize=False)

    def initialize_task(self, db):
        self.world = World.instance()

        if self.world is not None:
            if db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both":
                # attempt to get simulated robot object from World
                self.robot = self.world.scene.get_object(db.inputs.urRobot+'_articulation')
                if self.robot is None:
                    db.log_warn("The node could not initialize the simulated robot, to use for executing the task.")
                else:
                    self.robot.initialize()
            
            if db.inputs.executionMode == "Real" or db.inputs.executionMode == "Both":
                # attempt to get real robot object from World
                self.robot = self.world.scene.get_object(db.inputs.urRobot+'_articulation')
                self.robot_rtde = self.world.scene.get_object(db.inputs.urRobot+'_physical') # Notice! the _physical suffix is appended automatically here
                if self.robot_rtde is None:
                    db.log_warn("The node could not initialize the real rtde robot, to use for executing the task.")
            
                self.task_thread = threading.Thread(target=self.perform_task, args=(db,), daemon=False)

            if db.inputs.pose:
                self.pose_db = self.world.scene.get_object('pose_db')
                if self.pose_db is None:
                    db.log_warn("The node found no pose database!")
                else:
                    if db.inputs.localRefFrame:
                        self.frame_path = "/World/Robots/%s/%s" % (db.inputs.urRobot, db.inputs.localRefFrame)
                        #print(self.frame_path )
                        if is_prim_path_valid(self.frame_path):
                            #check if a pose with the unique name already exists and use it to generate cartesian pose
                            self.cartesian_pose_sim = get_pose_in_reference_frame(db, self.pose_db, self.frame_path, db.inputs.pose)
                            self.cartesian_pose_real = get_pose_in_reference_frame(db, self.pose_db, self.frame_path, db.inputs.pose)

                        else:
                            db.log_error("The provided reference frame does not exists!")
                        
                    else:
                        self.cartesian_pose_sim = self.pose_db.get_pose_from_db(db, db.inputs.pose)
                        self.cartesian_pose_real = self.pose_db.get_pose_from_db(db, db.inputs.pose)

                    if not self.cartesian_pose_sim:
                        db.log_error("Could not retrieve cartesian_pose from database!")
                        return False
                    elif len(self.cartesian_pose_sim) != 6:
                        db.log_error("Cartesian pose is not a valid pose! Length is incorrect.")
                        return False
                    
            elif db.inputs.frame:
                target_frame = db.inputs.frame[0].GetString()
                print("Will move to the frame:", target_frame)
                if db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both":
                    self.cartesian_pose_sim = copy.deepcopy(get_pose_from_frame_in_world(target_frame))
                   
                   
                    print("Target cartesian pose in World: ", self.cartesian_pose_sim)
                
                if db.inputs.executionMode == "Real" or db.inputs.executionMode == "Both":

                    # self.cartesian_pose_real = get_robot_pose_from_frame(target_frame, db.inputs.urRobot+'/ur5e')
                    self.cartesian_pose_real = copy.deepcopy(get_pose_from_frame_in_world(target_frame))
                    

                    print("Target cartesian pose in robot base is: ", self.cartesian_pose_real)
            else:
                # Assume manually entered pose through position and orientation attributes.
                self.cartesian_pose_sim = [db.inputs.position[0], db.inputs.position[1], db.inputs.position[2],
                                        db.inputs.rotation[0], db.inputs.rotation[1], db.inputs.rotation[2]]  
                 
                self.cartesian_pose_real = [db.inputs.position[0], db.inputs.position[1], db.inputs.position[2],
                        db.inputs.rotation[0], db.inputs.rotation[1], db.inputs.rotation[2]]                

        else:
            db.log_warn("A world with a scene has not been defined in Omniverse. Did you initialize the robot before calling this node?")

    def perform_task(self, db):
        '''
        Perform task or skill in a separate thread to avoid freezing the main UI thread.

        Parameters:
            db : internal node data 

        '''
        # perform moveL using the provided pose

        if self.robot_rtde:
            if db.inputs.pose:
                db.log_info("Moving "+db.inputs.urRobot+" to db pose: ("+str(db.inputs.pose)+") "+str(self.cartesian_pose_real))          
            elif db.inputs.frame:
                db.log_info("Moving "+db.inputs.urRobot+" to frame: ("+str(db.inputs.frame[0].GetString())+") "+str(self.cartesian_pose_real))
            else:
                db.log_info("Moving "+db.inputs.urRobot+" to manually entered pose: "+str(self.cartesian_pose_real))
            target_pose = self.cartesian_pose_real
            # self.articulation_traj = self.robot.get_interp_traj_cart_space_quaternion(target_pose, db.inputs.velocity)
            # print("Trajectory duration: ", self.articulation_traj.get_trajectory_duration())
            # self.action_sequence = self.articulation_traj.get_action_sequence() 
            
            joint_q = self.robot.get_target_pose(target_pose,db.inputs.velocity)
            print("joint",joint_q)
            # queue_log("joint q",joint_q)
            # self.moveJ(initial_joint_q, 0.1, 1.4, True) 
            
            start_time = time.time()
            self.robot_rtde.moveJ(joint_q,db.inputs.velocity,db.inputs.acceleration)
            end_time = time.time()

            duration_real = end_time -start_time
 
            db.log_info("Done moving "+db.inputs.urRobot)
        
            self.task_done = True
        


    def evaluate_task(self, db) -> bool:
        '''
        Evaluate and if possible verify whether the task or skill was successfully performed. If this task 
        is performed successfully and it can verified that it was done correctly this function returns True.
        If that is not the case False is returned. 

        Parameters:
            db : internal node data 

        Returns:
            success(bool) : True if preconditions are met, False otherwise
        '''
        success = True
        return success

    def check_preconditions(self, db) -> bool:
        '''
        Check any preconditions for performing this task or skill, if a precondition 
        is not met False should be returned, other this function returns True by default.

        Parameters:
            db : internal node data 

        Returns:
            preconditions_met(bool) : True if preconditions are met, False otherwise
        '''
        preconditions_met = True
            
        if not db.inputs.urRobot:
            db.log_warn("Please specify a UR robot to use for this movement!")
            preconditions_met = False
        
        return preconditions_met
    
    def reset_vars(self):
        self.action_index = 0
        self.task_done = False
        self.finish = False
        self.is_recording= False
        self.task_real_done = False
        self.cartesian_pose_sim = None
        self.cartesian_pose_real = None
        self.real_finish= False
        self.sim_logged= False
        if self.task_thread:
            self.task_thread.join()
            self.task_thread = None
            
    
    def custom_reset(self):
        self.reset_vars()
        self.initialized = False

    def make_interpolation(self, db):
        self.target_pose = self.cartesian_pose_sim
        # self.articulation_traj = self.robot.get_interpolated_traj_cartesian_space(self.target_pose, db.inputs.velocity,0.1)
        self.articulation_traj = self.robot.get_interp_traj_cart_space_quaternion(self.target_pose, db.inputs.velocity,db.inputs.acceleration)
        print("Trajectory duration: ", self.articulation_traj.get_trajectory_duration())
        sim_duration = self.articulation_traj.get_trajectory_duration()
        # with open("/home/nyll/Desktop/project/sdu/log/simulation_log000.txt", "a") as F:
        #     F.write(f"sim_duration:{sim_duration:.3f}")
        self.action_sequence = self.articulation_traj.get_action_sequence()
        print("sequemce",self.articulation_traj)
        print("tcp",self.robot.get_tcp())
        
        joint_q = self.robot.get_target_pose(self.target_pose,db.inputs.velocity)
        print("jq",joint_q)
        # queue_log(f"joint_q {', '.join(map(str, joint_q))}")

        

class OgnMoveLNode:
    """
    node for controlling a UR robot.
    """

    @staticmethod
    def internal_state():
        return OgnMoveLInternalState()

    @staticmethod
    def compute(db) -> bool:
        state = db.per_instance_state

        if not state.initialized:
            indicate_node_exec_running(db.node)
            
            state.initialize_task(db)
            # Check preconditions
            if not state.check_preconditions(db):
                return False

            print("Performing MoveL to: "+str(db.inputs.pose))

            if db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both":
                if db.inputs.sim_step == True:

                    omni.kit.commands.execute('ChangeProperty',
                        prop_path=Sdf.Path('/physicsScene.physxScene:timeStepsPerSecond'),
                        value=300,
                        prev=60,
                        target_layer=Sdf.Find('file:/home/nyll/Desktop/project/sdu/c207.usd'),
                        usd_context_name=omni.usd.get_context().get_stage())
                if state.robot is not None:
                    state.make_interpolation(db)

            if db.inputs.executionMode == "Real" or db.inputs.executionMode == "Both":
                # Perform task
                # state.make_interpolation(db)
                state.task_thread.start()
                # state.task_thread.join()

            state.initialized = True

        if state.initialized and (db.inputs.executionMode == "Simulation" or db.inputs.executionMode == "Both"):
            # sim_vel = state.robot.get_tcp_velocity()
            # print("sim velocity",sim_vel)
            if state.action_sequence is not None:
                # perform next action in trajectory if any left
                if state.action_index < len(state.action_sequence):
                    if state.action_index == 0:
                        # print("first")
                        state.sim_start_time = time.time()
                    state.robot.apply_articulation_action(state.action_sequence[state.action_index])
                    action_dict = state.action_sequence[state.action_index].get_dict()
                    joint_positions = action_dict['joint_positions']
                    state.iteration += 1


                    state.action_index += 1
                    
                # 
                else:
                    if not state.sim_logged:
                        sim_end_time = time.time()
                        sim_duration = sim_end_time - state.sim_start_time

                        state.sim_logged = True  #
                        indicate_node_exec_ended(db.node)
                        state.task_done = True


        if state.initialized :
            if state.task_done:
                # print("second")
            # Evaluate task
                success = state.evaluate_task(db)
                if success:
                    get_interface().set_execution_enabled("outputs:success")
                    # print("second")
                    if db.inputs.sim_record :
                        state.finish = False
                        db.outputs.finish = state.finish  
                    if db.inputs.real_record :
                        state.real_finish = False
                        db.outputs.real_finish = state.real_finish             
                    return True
                else:
                    get_interface().set_execution_enabled("outputs:error")
                    return False
            else:
                if db.inputs.sim_record :
                    state.finish = True
                    db.outputs.finish = state.finish  
                if db.inputs.real_record :
                    # print("wwrite real")
                    state.real_finish = True
                    db.outputs.real_finish = state.real_finish
                    # print(db.outputs.real_finish)

       
  
    
        return True

    @staticmethod
    def release(node):
        try:
            state = OgnMoveLNodeDatabase.get_internal_state(node)
        except Exception:
            state = None
            pass

        if state is not None:
            state.custom_reset()