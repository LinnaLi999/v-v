
from omni.isaac.core_nodes import BaseResetNode
from omni.isaac.core.prims.xform_prim import XFormPrim
from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core.scenes.scene import Scene
from omni.sdu.ur.scripts.robotiq_gripper import RobotiqGripper
import os
from omni.sdu.ur.ogn.OgnGripperNodeDatabase import OgnGripperNodeDatabase
from omni.graph.action import get_interface
# from rtde_robotiq_gripper import eMoveMode
import time
class Gripper(XFormPrim, RobotiqGripper):
   def __init__(self, ip: str, prim_path: str, name: str):
       self._ip = ip
       self._port = 63352  # Robotiq UR Cap port
       RobotiqGripper.__init__(self)
       self.connect(self._ip, self._port)
       XFormPrim.__init__(self, prim_path=prim_path, name=name)
   def initialize(self, physics_sim_view=None) -> None:
       """To be called before using this class after a reset of the world"""
       XFormPrim.initialize(self, physics_sim_view=physics_sim_view)
       return
   def post_reset(self) -> None:
       return

class OgnGripperNodeInternalState(BaseResetNode):
   def __init__(self):
       self._world = None
       self.initialized = False
       self.moved = False 
       self.gripper_ip = None
       self.gripper_path = None
       self.gripper = None
       super().__init__(initialize=False)
   def initialize_gripper(self):
       if self.initialized:
           print("Gripper already initialized, skipping activation.")
           return
       if not World.instance():
           self._world = World(stage_units_in_meters=1.0)
           self._world.scene.add_default_ground_plane(-0.74)
       else:
           self._world = World.instance()
       obj_name = os.path.basename(self.gripper_path) + '_real'
       print("Creating gripper object:", obj_name)
       try:
           self.gripper = Gripper(ip=self.gripper_ip, prim_path="/World/" + obj_name, name=obj_name)
           
           print("Activating gripper...")
           self.gripper.activate()
           print("Gripper activated.")
        #    self.gripper.initialize()
           self._world.scene.add(self.gripper)
           self.initialized = True
           self.task_done = True  
           self.moved = False  
        #    self.gripper.move_and_wait_for_pos(position=200,speed=255,force=255)
           print("Gripper successfully initialized.")
       except Exception as e:
           print(f"Gripper initialization failed: {e}")


   def reset_vars(self):
       print("Resetting internal state...")
       self.initialized = False
       self.moved = False  
       self.task_done = False
   def custom_reset(self):
       self.reset_vars()
       if self.gripper:
           self.gripper.disconnect()
           self._world.scene.remove_object(self.gripper.name)
           del self.gripper
           self.gripper = None

class OgnGripperNode:
    """Node for controlling a gripper."""
    @staticmethod
    def internal_state():
        return OgnGripperNodeInternalState()
    @staticmethod
    def compute(db) -> bool:
        state = db.internal_state
        try:

            if state.initialized:
                state.moved = True
                # print("Gripper is already initialized, skipping reinitialization.")
            else:
                state.gripper_ip = db.inputs.gripperIP
                if not state.gripper_ip:
                    db.log_warn("Please indicate the gripper IP before initializing!")
                    return False
                state.gripper_path = db.inputs.gripperPath
                if not state.gripper_path:
                    db.log_warn("Please provide a path to the simulated gripper!")
                    return False
                state.initialize_gripper()

            if state.initialized and state.task_done:
            # Evaluate task
                # print("state",state.task_done)
                db.outputs.execOut = og.ExecutionAttributeState.ENABLED

                # get_interface().set_execution_enabled("outputs:success")
                return True
                # success = True
                # if success:
                #     get_interface().set_execution_enabled("outputs:success")
                #     return True
                # else:
                #     get_interface().set_execution_enabled("outputs:error")
                #     return False

            
            
        except Exception as error:
            db.log_warn(str(error))
            return False
        return True
    
    @staticmethod
    def release(node):
        try:
            state = OgnGripperNodeDatabase.per_node_internal_state(node)
        except Exception:
            state = None
            pass
        if state is not None:
            state.reset()