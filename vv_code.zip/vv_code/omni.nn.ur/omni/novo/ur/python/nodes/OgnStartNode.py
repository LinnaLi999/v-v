from contextlib import suppress

import carb.events
import omni.kit.app
from omni.isaac.core_nodes import BaseResetNode
from omni.sdu.ur.ogn.OgnStartNodeDatabase import OgnStartNodeDatabase
import omni.usd
from omni.graph.action import get_interface
from omni.isaac.core.utils.prims import get_prim_at_path
from pxr import Gf, UsdGeom
import random
def registered_event_name(event_name):
    """Returns the internal name used for the given custom event name"""
    n = "omni.graph.action." + event_name
    return carb.events.type_from_string(n)

class OgnStartInternalState(BaseResetNode):
    """Convenience class for maintaining per-node state information"""

    def __init__(self):
        super().__init__(initialize=False)
        self.sub = None  # The stage-event subscription holder
        self.should_execute = False  # Set to True when a execution event has been received

    def first_time_subscribe(self):
        """Set up the stage event subscription"""
        reg_event_name = registered_event_name("ROBOT_EXECUTION_EVENT")
        message_bus = omni.kit.app.get_app().get_message_bus_event_stream()
        self.sub = message_bus.create_subscription_to_pop_by_type(reg_event_name, self.on_event)

    def on_event(self, e: carb.events.IEvent):
        """The event callback"""
        if e is None:
            return
        self.payload = e.payload
        print("Event received, payload: ", self.payload)
        if self.payload['execution_mode'] == 1:
            self.should_execute = True
        elif self.payload['execution_mode'] == 2:
            self.should_execute = False
    
    def custom_reset(self):
        print('Got custom_reset')
        self.should_execute = False


class OgnStartNode:
    @staticmethod
    def internal_state():
        """Returns an object that will contain per-node state information"""
        return OgnStartInternalState()

    @staticmethod
    def release_instance(node, graph_instance_id):
        """Clean up the subscription when node is removed"""
        state = OgnStartNodeDatabase.per_instance_internal_state(node)
        state.should_execute = False

        if state.sub:
            state.sub.unsubscribe()
            state.sub = None

    @staticmethod
    def compute(db) -> bool:
        state = db.per_instance_state
        
        if state.sub is None:
            # The initial compute call, set up our subscription
            state.first_time_subscribe()

        if state.should_execute:
            get_interface().set_execution_enabled("outputs:execOut")

        return True