"""
This is the implementation of the OGN node defined in OgnTouchUpZCheck.ogn
"""

# Array or tuple values are accessed as numpy arrays so you probably need this import
from omni.isaac.core import World
import omni.graph.core as og
from omni.isaac.core_nodes import BaseResetNode
import threading
import numpy as np
import time
from omni.sdu.ur.ogn.OgnTouchUpZCheckDatabase import OgnTouchUpZCheckDatabase
from omni.sdu.core.utilities.utils import indicate_node_exec_running, indicate_node_exec_ended

class OgnTouchUpZCheckInternalState(BaseResetNode):

    def __init__(self):
        self.initialized = False
        self.task_thread = None
        self.is_task_done = False
        self.within_spec = False
        self.pose_db = None
        self.robot_rtde = None
        super().__init__(initialize=False)

    def initialize_task(self, db):
        # Attempt to retrieve the specified pose from the database
        
        # attempt to get pose database from world
        world = World.instance()
        if world is None:
            db.log_warn("The world died...")
        else:
            print("3")
            # attempt to get specified robot from World
            self.robot_rtde = world.scene.get_object(db.inputs.urRobot + '_physical')
            if self.robot_rtde is None:
                db.log_warn("The node found no robot to move, please provide a robot!")
            print("4")
            # self.pose_db = world.scene.get_object("pose_db")
            # if self.pose_db is None:
            #     print("5")
            #     db.log_warn("The node found no pose data base!")
            
            print("third")
            self.expected_difference = 0
            if db.inputs.expected_z is not None:
                self.expected_difference = db.inputs.expected_z
            else:
                db.log_warn("The node got no expected difference!")

            self.speed = np.zeros(6)
            if db.inputs.tool_speed_z is not None:
                self.speed[2] = db.inputs.tool_speed_z
            else:
                db.log_warn("The node got no expected z speed!")
            
            if db.inputs.tolerance_z is not None:
                self.tolerance = db.inputs.tolerance_z
            else:
                db.log_warn("The node got no expected z tolerance!")
            self.task_thread = threading.Thread(target=self.perform_task, args=(db,), daemon=False)

    def perform_task(self, db):
        """
        Perform task or skill in a separate thread to avoid freezing the main UI thread.

        Parameters:
            db : internal node data 

        """
        # Enter force mode with specified parameters
        if self.robot_rtde:
            print("enter z touch")
            time.sleep(0.2)
            tcp_pose_initial = self.robot_rtde.getActualTCPPose()
            self.robot_rtde.zeroFtSensor() # reset force sensor due to drift
            time.sleep(0.2)
            speed = [0, 0, -0.01, 0, 0, 0]
            self.move_until_contact_force_based(speed_vec=speed, force_threshold=1,axis=2,timeout=100)
            current_tcp_pose = self.robot_rtde.getActualTCPPose()
            deviation = current_tcp_pose[2] - tcp_pose_initial[2]
            print("deviation",deviation)
            self.within_spec = False
            diff1 = self.expected_difference - self.tolerance
            diff2 = self.expected_difference + self.tolerance
            print("diff1",diff1)
            print("diff2",diff2)
            if deviation > self.expected_difference - self.tolerance and deviation < self.expected_difference + self.tolerance:
                self.within_spec = True
                print("spec",self.within_spec)
                
            
            self.robot_rtde.moveL(tcp_pose_initial)

            
            self.is_task_done = True
            


    def evaluate_task(self, db) -> bool:
        """
        Evaluate and if possible verify whether the task or skill was successfully performed. If this task 
        is performed successfully and it can verified that it was done correctly this function returns True.
        If that is not the case False is returned. 

        Parameters:
            db : internal node data 

        Returns:
            success(bool) : True if preconditions are met, False otherwise
        """
        success = self.within_spec
        return success

    def check_preconditions(self, db) -> bool:
        """
        Check any preconditions for performing this task or skill, if a precondition 
        is not met False should be returned, other this function returns True by default.

        Parameters:
            db : internal node data 

        Returns:
            preconditions_met(bool) : True if preconditions are met, False otherwise
        """
        preconditions_met = True
            
        if not db.inputs.urRobot:
            db.log_warn("Please specify a UR robot to use for this movement!")
            preconditions_met = False
        
        return preconditions_met
    
    def reset_vars(self):
        self.is_task_done = False
        if self.initialized:
           if self.task_thread:
               self.task_thread.join()
               self.task_thread = None
        self.initialized = False
    
    def custom_reset(self):
        self.reset_vars()
        if self.robot_rtde is not None:      
            del self.robot_rtde
            self.robot_rtde = None
    def move_until_contact_force_based(self,
                                speed_vec,
                                force_threshold=8.0,
                                axis=2,
                                timeout=100.0,
                                rate=10):

    
        self.robot_rtde.zeroFtSensor()
        print("start to contact")
        rate_dt = 1.0 / rate
        start_time = time.time()
        while time.time() - start_time < timeout:
            self.robot_rtde.speedL(speed_vec, 0.1, 0.1)
            force = self.robot_rtde.getActualTCPForce()
            print(f"[Contact] current axis {axis} force = {force[axis]:.2f} N")
            if abs(force[axis]) > force_threshold:
                print(f"[Contact]stat:{force[axis]:.2f} N > thres {force_threshold} N")
                break
            time.sleep(rate_dt)
        else:
            
            self.robot_rtde.speedStop()
            return False
        
        self.robot_rtde.speedStop()
        time.sleep(0.2)
        return True       

class OgnTouchUpZCheck:
    """
         Node to move the robot until contact, with specified speed and contact detection
     direction.
    """
    @staticmethod
    def internal_state():
        return OgnTouchUpZCheckInternalState()
    
    @staticmethod
    def compute(db) -> bool:
        try:

            state = db.internal_state

            print(db.inputs.runInSimulation)
            if not db.inputs.runInSimulation:

                print(state.initialized)
                if not state.initialized:
                    indicate_node_exec_running(db.node)

                    state.initialize_task(db)
                    # Check preconditions
                    if not state.check_preconditions(db):
                        return False

                    # Perform task
                    print("second")
                    state.task_thread.start()
                    state.initialized = True
            else:
                state.is_task_done = True
                state.within_spec = True
            print("task",state.is_task_done)
            # Check if the task has finished
            if state.is_task_done:
                
                # Reset variables to allow running again
                # state.reset_vars()

                indicate_node_exec_ended(db.node)

                # Evaluate task
                success = state.evaluate_task(db)
                print("final",success)
                if success:
                    # signal that we are done, so that execution flow continues downstream.
                    db.outputs.success = og.ExecutionAttributeState.LATENT_FINISH
                    return True
                else:
                    db.outputs.success = og.ExecutionAttributeState.DISABLED
                    db.outputs.error = og.ExecutionAttributeState.LATENT_FINISH
                    return False
        
        except Exception as error:
            db.log_warn(str(error))
            return False

    
        # save the current node as it performs some asynchronous operation
        db.outputs.success = og.ExecutionAttributeState.LATENT_PUSH
        return True

    @staticmethod
    def release(node):
        try:
            state = OgnTouchUpZCheckDatabase.per_node_internal_state(node)
        except Exception:
            state = None
            pass

        if state is not None:
            state.reset()