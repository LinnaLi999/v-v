"""Support required by the Carbonite extension loader"""
from contextlib import suppress
from typing import List

import omni.ext
from omni.kit.app import get_app

class _PublicExtension(omni.ext.IExt):
    """Object that tracks the lifetime of the Python part of the extension loading"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        with suppress(ImportError):
            manager = get_app().get_extension_manager()
            # This is a bit of a hack to make the template directory visible to the OmniGraph UI extension
            # if it happens to already be enabled. The "hack" part is that this logic really should be in
            # omni.graph.ui, but it would be much more complicated there, requiring management of extensions
            # that both do and do not have dependencies on omni.graph.ui.
            if manager.is_extension_enabled("omni.graph.ui"):
                import omni.graph.ui as ogui  # noqa: PLW0621

                ogui.ComputeNodeWidget.get_instance().add_template_path(__file__)

    def on_startup(self):
        print("[omni.sdu.ur] OmniSduUrExtension startup", flush=True)


    def on_shutdown(self):
        print("[omni.sdu.ur] OmniSduUrExtension shutdown", flush=True)
