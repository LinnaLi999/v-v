# SDU UR Extension [omni.sdu.ur]

ISAAC Extension that implements OmniGraph nodes for controlling a UR Robot

![Preview](data/preview.png)

## Dependencies
The python dependencies are:
* [numpy](https://pypi.org/project/numpy/)
* [scipy](https://pypi.org/project/scipy/)
* [ur_rtde](https://pypi.org/project/ur-rtde/)

The ISAAC sim dependencies are:
* [omni.sdu.core](https://gitlab.sdu.dk/sdurobotics/novo/omni.sdu.core)

## Getting started 

Follow the instructions in the [omni.sdu.core](https://gitlab.sdu.dk/sdurobotics/novo/omni.sdu.core) repository to 
install that extension.

Next, simply clone this repository to ~/Documents/Kit/shared/exts or preferred folder with extensions:

    cd ~/Documents/Kit/shared/exts
    git clone git@gitlab.sdu.dk:sdurobotics/novo/omni.sdu.ur.git

and finally remember to enable the extension in the omniverse extension manager.