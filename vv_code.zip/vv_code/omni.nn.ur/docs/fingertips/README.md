
# FINGER DESCRIPTION FOR NOVO ASSEMBLY LINE

## Fingers used

### Housing & Scaledrum

<img src="./images/Housing_ScaleDrum.png" alt="finger" width="300"/>

### Connector Pipe

<img src="./images/ConnectorPipe.png" alt="finger2" width="300"/>

## Clutch & Push button

<img src="./images/Clutch_PushButton.png" alt="finger" width="300"/>


## Layout in the plate

Given the plate:

![Plate](./images/poses.fingertip.png)

### A: Housing & Scaledrum

### B: Clutch & Push button

### C: Connector Pipe

## Poses and Joint configurations for robots

Poses and Joint configuration with no specific format can be found in the document "poses_raw.txt"