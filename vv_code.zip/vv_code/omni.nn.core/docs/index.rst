omni.sdu.utils
#############################

Example of Python only extension


.. toctree::
   :maxdepth: 1

   README
   CHANGELOG


.. automodule::"omni.sdu.utils"
    :platform: Windows-x86_64, Linux-x86_64
    :members:
    :undoc-members:
    :show-inheritance:
    :imported-members:
    :exclude-members: contextmanager
