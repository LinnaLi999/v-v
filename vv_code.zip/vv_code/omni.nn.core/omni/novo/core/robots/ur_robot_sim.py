# omniverse imports
import carb
import lula
from pxr import Gf


from omni.isaac.core.prims.rigid_prim import RigidPrim
from omni.isaac.core.prims.xform_prim import XFormPrim
from omni.isaac.core.utils.rotations import quat_to_euler_angles
from omni.isaac.motion_generation import LulaKinematicsSolver
from omni.isaac.motion_generation import ArticulationTrajectory
from omni.isaac.motion_generation.lula.trajectory_generator import LulaCSpaceTrajectoryGenerator
from omni.isaac.core.utils.types import ArticulationAction
from omni.isaac.core.articulations.articulation import Articulation
from omni.sdu.core.utilities import utils as ut
from scipy.spatial.transform import Rotation as R, Slerp
import numpy as np
import math
# other imports
import numpy as np
import os
import math
from typing import Optional, Sequence
from scipy.spatial.transform import Rotation as R
from omni.sdu.core.trajectory.trajectory import jtraj


class URRobotSim(XFormPrim):
    """Class for instantiating a simulated UR robot.

    Args:
        Articulation (_type_): _description_
    """

    def __init__(
        self,
        robot_type: str = "ur5e",
        prim_path: str = "/World/",
        name: str = "ur5e_robot",
        initial_joint_q: np.ndarray = np.array(
            [0.0, -1.5707, 1.5707, -1.5707, -1.5707, 0.0]
        ),
        calibrated_urdf_path: str = None,
        position: Optional[Sequence[float]] = None,
        orientation: Optional[Sequence[float]] = None,
        scale: Optional[Sequence[float]] = [1.0, 1.0, 1.0],
        end_effector_name: str = "tool0",
        end_effector_offset: Optional[Sequence[float]] = [0.19, 0, 0],
    ) -> None:
        self._robot_type = robot_type
        self._prim_path = prim_path + "/" + robot_type
        self._name = name
        if self._name is None:
            self._name = prim_path.split("/")[-1]
        self._initial_joint_q = initial_joint_q
        self._calibrated_urdf_path = calibrated_urdf_path
        self._world_position = position
        self._world_orientation = orientation
        self._scale = scale
        self._end_effector_name = end_effector_name
        self._end_effector_offset = np.array(end_effector_offset)
        self._end_effector = None
        self._controller_handle = None
        self.current_q = None
        self.target_q = None
        XFormPrim.__init__(self, prim_path="/World/" + name, name=name)

    def initialize(self, physics_sim_view=None) -> None:
        """To be called before using this class after a reset of the world

        Args:
            physics_sim_view (_type_, optional): _description_. Defaults to None.
        """
        # XFormPrim.initialize(self, physics_sim_view=physics_sim_view)
        return

    def initialize_controller(self):
        self._controller_handle = Articulation(
            prim_path=self._prim_path,
            position=self._world_position,
            translation=None,
            orientation=self._world_orientation,
            scale=self._scale,
            visible=None,
        )
        if self._end_effector:
            initial_state = np.append(self._initial_joint_q, np.zeros(2))
        else:
            initial_state = self._initial_joint_q
        self._controller_handle.initialize()
        self._controller_handle.set_joints_default_state(positions=initial_state)
        self.init_motion_control()
        self._controller_handle.post_reset()
        self.initialized = True

    def init_motion_control(self):
        rmp_config_dir = os.path.join(
            os.path.dirname(os.path.realpath(__file__)), self._robot_type + "_assets"
        )
        robot_description_path = os.path.join(
            rmp_config_dir, self._robot_type + "_robot_description.yaml"
        )
        if self._calibrated_urdf_path:
            print(
               "NOTICE! using custom calibrated urdf path: ",
               self._calibrated_urdf_path
            )
            urdf_path = self._calibrated_urdf_path
        else:
            urdf_path = os.path.join(rmp_config_dir, self._robot_type + ".urdf")
            print(
               "using default urdf path: ",
               urdf_path
            )

        self._kinematics = LulaKinematicsSolver(
            robot_description_path=robot_description_path, urdf_path=urdf_path
        )
        self._joint_space_trajectory_generator = LulaCSpaceTrajectoryGenerator(
            robot_description_path=robot_description_path, urdf_path=urdf_path
        )

        # robot_prim = XFormPrim(prim_path="/World/Robots/robotB")
        # robot_base_isaac_pose = robot_prim.get_world_pose()
        # print("robot_base_isaac_pose (pos): ", robot_base_isaac_pose[0])
        # print("robot_base_isaac_pose (rot): ", quat_to_euler_angles(robot_base_isaac_pose[1], degrees=True))
        # print("robot_base_isaac_pose: ", robot_base_isaac_pose)
        # rotate_180_on_z_quat = Gf.Quatf(0, 0, 0, 1)
        # rotate_180_on_z_quat_xyzw = (rotate_180_on_z_quat.GetReal(), *rotate_180_on_z_quat.GetImaginary())

        world_pose = self._controller_handle.get_world_pose()
        print("World pose (pos): ", world_pose[0])
        print("World pose (rot): ", quat_to_euler_angles(world_pose[1], degrees=True))
        self._kinematics.set_robot_base_pose(
            robot_position=world_pose[0],
            robot_orientation=world_pose[1]
        )

    def post_reset(self) -> None:
        if self._controller_handle:
            self._controller_handle.post_reset()
        return

    def get_robot_type(self):
        return self._robot_type

    def moveL(
        self,
        target_position: Optional[Sequence[float]] = None,
        target_orientation: Optional[Sequence[float]] = None,
    ):
        # TODO: Should be removed
        action = self._cspace_controller.forward(
            target_end_effector_position=target_position,
            target_end_effector_orientation=target_orientation,
        )
        self._articulation_controller.apply_action(action)

    def moveJ(self, joint_q):
        """Move robot to desired joint position

        Args:
            joint_q (array): desired joint position
        Return:
        """
        if not len(joint_q) > 6:
            joint_q = np.concatenate((joint_q, np.array([0.0, 0.0])), axis=0)
        self.apply_articulationAction(joint_positions=np.array(joint_q))
        return

    def moveJ_with_params(self, joint_q, joint_velocities, joint_accelerations):
        """Move robot to desired joint position

        Args:
            joint_q (array): desired joint position
        Return:
        """
        current_gri = self.get_joint_positions()[-2:]
        if not len(joint_q) > 6:
           joint_q = np.concatenate((joint_q, current_gri), axis=0)
        if not len(joint_velocities) > 6:
           joint_velocities = np.concatenate((joint_velocities, np.array([0.0, 0.0])), axis=0)
        self.apply_articulationAction(
            joint_positions=np.array(joint_q),
            joint_velocities=np.array(joint_velocities)
        )
        return
    


    def get_interpolated_traj_cartesian_space(self, current_pose, target_pose, v_max, a_max, seed_q=None):
        pos_start = np.array(current_pose[0:3])
        pos_end = np.array(target_pose[0:3])
        path_length = np.linalg.norm(pos_end - pos_start)
        # === Step 1: Estimate total trajectory duration based on trapezoidal speed profile ===
        d_acc = v_max**2 / (2 * a_max)
        if path_length >= 2 * d_acc:
            # Full trapezoidal profile
            t_acc = v_max / a_max
            t_flat = (path_length - 2 * d_acc) / v_max
            total_time = 2 * t_acc + t_flat
        else:
            # Triangle profile (never reaches max speed)
            v_peak = np.sqrt(a_max * path_length)
            t_acc = v_peak / a_max
            total_time = 2 * t_acc
        # === Step 2: Set time samples ===
        num_points = 60
        t_array = np.linspace(0.0, total_time, num=num_points)
        # === Step 3: Prepare SLERP for rotation interpolation ===
        rot_start = R.from_rotvec(current_pose[3:6])
        rot_end = R.from_rotvec(target_pose[3:6])
        slerp = Slerp([0, 1], R.concatenate([rot_start, rot_end]))
        def trapezoidal_alpha(t):
            if path_length >= 2 * d_acc:
                if t < t_acc:
                    return 0.5 * a_max * t**2 / path_length
                elif t < t_acc + t_flat:
                    return (d_acc + v_max * (t - t_acc)) / path_length
                elif t <= total_time:
                    t_dec = t - t_acc - t_flat
                    return (d_acc + v_max * t_flat + v_max * t_dec - 0.5 * a_max * t_dec**2) / path_length
                else:
                    return 1.0
            else:
                v_peak = np.sqrt(a_max * path_length)
                t_peak = v_peak / a_max
                if t < t_peak:
                    return 0.5 * a_max * t**2 / path_length
                elif t <= total_time:
                    t_dec = t - t_peak
                    return (0.5 * path_length + v_peak * t_dec - 0.5 * a_max * t_dec**2) / path_length
                else:
                    return 1.0
        # === Step 4: Interpolate poses and solve IK ===
        c_space_points = []
        for t in t_array:
            alpha = trapezoidal_alpha(t)
            pos_interp = (1 - alpha) * pos_start + alpha * pos_end
            rot_interp = slerp([alpha])[0]
            rot_mat = rot_interp.as_matrix()
            pose_lula = lula.Pose3(lula.Rotation3(rot_mat), pos_interp)
            if seed_q is not None:
                q_interp = self.get_inverse_kinematics(pose_lula, seed=seed_q)
            else:
                q_interp = self.get_inverse_kinematics(pose_lula)
            if q_interp is not None:
                c_space_points.append(q_interp)
                seed_q = q_interp
            else:
                print(f"IK failed at t={t:.3f} (alpha={alpha:.3f})")
        if len(c_space_points) < 2:
            print("Too few valid IK points, aborting trajectory generation.")
            return None
        c_space_points_timestamps = np.linspace(0.0, total_time, num=len(c_space_points))
        trajectory = self._joint_space_trajectory_generator.compute_timestamped_c_space_trajectory(
            c_space_points,
            c_space_points_timestamps,
            interpolation_mode="linear"
        )
        if trajectory is None:
            print("No trajectory could be generated!")
            return None
        physics_dt = 1 / 60.0
        articulation_trajectory = ArticulationTrajectory(
            self._controller_handle, trajectory, physics_dt
        )
        print("total time",total_time)
        return articulation_trajectory

    def get_target_pose(self, target_pose, velocity, seed_q=None):

        current_q = self.get_joint_positions()[:6] #  [:6]
        target_pose_pos = target_pose[0]
        target_pose_quat = target_pose[1]
        target_pose_lula = lula.Pose3(
            lula.Rotation3(R.from_quat(target_pose_quat).as_matrix()),
            target_pose_pos,
        )
        print("target pose lula:", target_pose_lula)

        print('current_q:', current_q)
        self.current_q = current_q
        if seed_q is not None:
            target_q = self.get_inverse_kinematics(target_pose_lula, seed=current_q)
        else:
            target_q = self.get_inverse_kinematics(target_pose_lula)

        print("target pose lula after in:", target_pose_lula)

        print("current q:", current_q)
        print("target q:", target_q)
        self.target_q = target_q
        target_q1 = np.degrees(target_q)
        print("target q degree", target_q1)
        return self.target_q
    def get_interp_traj_cart_space_quaternion(self, target_pose, velocity, acceleration, seed_q=None):
        current_q = self.get_joint_positions()[:6]
        target_pos, target_quat = target_pose
        # Step 1: Pose → IK target joint config
        target_pose_lula = lula.Pose3(
            lula.Rotation3(R.from_quat(target_quat).as_matrix()),
            target_pos,
        )
        if seed_q is not None:
            target_q = self.get_inverse_kinematics(target_pose_lula, seed=seed_q)
        else:
            target_q = self.get_inverse_kinematics(target_pose_lula)
        if target_q is None:
            print("IK failed!")
            return None
        # Step 2: Compute trajectory duration using trapezoidal velocity profile (UR-like)
        joint_deltas = np.abs(np.array(target_q) - np.array(current_q))
        max_delta = np.max(joint_deltas)
        d_acc = velocity**2 / (2 * acceleration)
        if max_delta >= 2 * d_acc:
            # Trapezoidal: reaches max speed
            t_acc = velocity / acceleration
            t_flat = (max_delta - 2 * d_acc) / velocity
            T_total = 2 * t_acc + t_flat
        else:
            # Triangular: can't reach max speed
            v_peak = np.sqrt(acceleration * max_delta)
            t_acc = v_peak / acceleration
            T_total = 2 * t_acc
        print(f"[Trajectory Planning] Max joint delta: {max_delta:.4f}, Total duration: {T_total:.4f} s")
        with open("/home/nyll/Desktop/project/sdu/log/simulation_loga.txt", "a") as F:
            F.write(f"sim_duration:{T_total:.3f}")
        # Step 3: Interpolate joint trajectory
        dt = 1 / 60.0
        num_points = int(T_total / dt) + 1
        t_array = np.linspace(0.0, T_total, num=num_points)
        j_traj = jtraj(current_q, target_q, t_array).q
        c_space_points = j_traj
        c_space_points_timestamps = t_array
        # Step 4: Package into ArticulationTrajectory
        trajectory = self._joint_space_trajectory_generator.compute_timestamped_c_space_trajectory(
            c_space_points,
            c_space_points_timestamps,
            interpolation_mode="linear"
        )
        if trajectory is None:
            print("No trajectory could be generated!")
            return None
        articulation_trajectory = ArticulationTrajectory(
            self._controller_handle,
            trajectory,
            dt
        )
        return articulation_trajectory



    def get_interpolated_traj_joint_space(
        self, current_q, target_q, velocity,acceleration
    ):
        current_q = current_q[:6]
        target_q = target_q[:6]
        joint_deltas = np.abs(np.array(target_q) - np.array(current_q))
        max_delta = np.max(joint_deltas)

        d_acc = velocity**2 / (2 * acceleration)

        if max_delta >= 2 * d_acc:

            t_acc = velocity / acceleration
            t_flat = (max_delta - 2 * d_acc) / velocity
            T_total = 2 * t_acc + t_flat
        else:

            v_peak = np.sqrt(acceleration * max_delta)
            t_acc = v_peak / acceleration
            T_total = 2 * t_acc
        print(f"[Joint Trapezoidal] Max delta: {max_delta:.4f}, Duration: {T_total:.4f}s")
        # Step 3:  joint trajectory
        dt = 1 / 60.0
        num_points = int(T_total / dt) + 1
        t_array = np.linspace(0.0, T_total, num=num_points)
 
        j_traj = jtraj(current_q, target_q, t_array).q
        c_space_points = j_traj
        c_space_points_timestamps = t_array
        # Step 4:  ArticulationTrajectory
        trajectory = self._joint_space_trajectory_generator.compute_timestamped_c_space_trajectory(
            c_space_points,
            c_space_points_timestamps,
            interpolation_mode="linear"
        )
        if trajectory is None:
            print("No trajectory could be generated!")
            return None
        articulation_trajectory = ArticulationTrajectory(
            self._controller_handle,
            trajectory,
            dt
        )
        return articulation_trajectory


    def get_initial_joint_position(self):
        """_summary_

        Returns:
            _type_: _description_
        """
        return self._initial_joint_q

    def set_joint_velocities(self, velocity):
        if self._end_effector is not None:
            velocities = np.full(8, velocity)
        else:
            velocities = np.full(6, velocity)
        self._controller_handle.set_joint_velocities(velocities)

    def movePose3(self, target_pose=lula.Pose3):
        """Solving IK problem for target pose. Applies joints articulation

        Args:
            target_pose (lula.Pose3): _description_
        Return:
        """
        joint_pos = self.get_inverse_kinematics(target_pose)
        if self.gripper is not None:
            # TODO: Assumes parallel gripper. Must be more generic
            joint_pos = np.concatenate((joint_pos, np.array([0.0, 0.0])), axis=0)
        self.apply_articulationAction(joint_positions=joint_pos)
        return

    def apply_articulationAction(
        self,
        joint_positions: Optional[Sequence[float]] = None,
        joint_velocities: Optional[Sequence[float]] = None,
        joint_efforts: Optional[Sequence[float]] = None,
        joint_indices: Optional[Sequence[float]] = None,
    ):
        action = ArticulationAction(
            joint_positions=joint_positions,
            joint_velocities=joint_velocities,
            joint_efforts=joint_efforts,
            joint_indices=joint_indices,
        )
        self._controller_handle.apply_action(action) 

    def apply_articulation_action(self, articulation_action):
        self._controller_handle.apply_action(articulation_action)

    def teleport_robot_to_position(self, articulation_action):
        initial_positions = np.zeros(self._controller_handle.num_dof)
        initial_positions[articulation_action.joint_indices] = articulation_action.joint_positions

        self._controller_handle.set_joint_positions(initial_positions)
        self._controller_handle.set_joint_velocities(np.zeros_like(initial_positions))

    @property
    def end_effector(self) -> RigidPrim:
        """
        Returns:
            RigidPrim: end effector of the manipulator (can be used to get its world pose, angular velocity..etc).
        """
        return self._end_effector

    # def get_tcp(self) -> lula.Pose3:
    #     """Compute tcp pose with end_effector_offset

    #     Returns:
    #         lula.Pose3:
    #     """
    #     # TODO: Make it generic for any joint robot with or without gripper
    #     # Assumes 6 joint robot
    #     tcp = self._kinematics.compute_forward_kinematics(
    #         frame_name=self._end_effector_name,
    #         joint_positions=self._controller_handle.get_joint_positions()[:6],
    #     )
    #     offset = lula.Pose3.from_translation(self._end_effector_offset)
    #     flange = lula.Pose3(lula.Rotation3(np.array(tcp[1])), np.array(tcp[0]))
    #     tcp = flange * offset
    #     return tcp
    def get_tcp(self) -> lula.Pose3:
        """Compute TCP pose for UR5e with full flange and tool0 offset."""

        tcp = self._kinematics.compute_forward_kinematics(
            frame_name="wrist_3_link",  
            joint_positions=self._controller_handle.get_joint_positions()[:6],
        )
        wrist3_pose = lula.Pose3(
            lula.Rotation3(np.array(tcp[1])),  # rotation matrix
            np.array(tcp[0])                   # translation vector
        )
    

        flange_rpy = [0, -np.pi/2, -np.pi/2]
        flange_rot = R.from_euler("xyz", flange_rpy).as_matrix()
        flange_pose = lula.Pose3(lula.Rotation3(flange_rot), [0, 0, 0])
    

        tool0_rpy = [np.pi/2, 0, np.pi/2]
        tool0_rot = R.from_euler("xyz", tool0_rpy).as_matrix()
        tool0_pose = lula.Pose3(lula.Rotation3(tool0_rot), [0.19, 0, 0])
    
        # Step 4: TCP = wrist3 * flange * tool0
        tcp_pose = wrist3_pose * flange_pose * tool0_pose
    
        return tcp_pose
    def get_joint_positions(self):
        return self._controller_handle.get_joint_positions()

    def get_forward_kinematics(
        self, joint_positions: Optional[Sequence[float]] = None
    ) -> lula.Pose3:
        """Compute tcp pose with end_effector_offset

        Returns:
            lula.Pose3:
        """
        # TODO: Make it generic for any joint robot with or without gripper
        # Assumes 6 joint robot
        tcp = self._kinematics.compute_forward_kinematics(
            frame_name=self._end_effector_name, joint_positions=joint_positions
        )
        offset = lula.Pose3.from_translation(self._end_effector_offset)
        flange = lula.Pose3(lula.Rotation3(np.array(tcp[1])), np.array(tcp[0]))
        tcp = flange * offset
        return tcp

    def get_inverse_kinematics(
        self, target_pose=lula.Pose3, seed: Optional[Sequence[float]] = None
    ):
        """Compute the joint positions to a target pose

        Args:
            target_pose (lula.Pose3):

        Returns:
            np.array(): Target joint position
        """
        # TODO: Make it generic for any joint robot with or without gripper
        # Assumes 6 joint robot
        #offset_pose = lula.Pose3.from_translation(np.array(self._end_effector_offset))
        #goal = target_pose * offset_pose.inverse()
        if seed is None:
            seed_joint_pos = self._controller_handle.get_joint_positions()[:6]  # [:6]
        else:
            seed_joint_pos = seed
        target_joint_position, success = self._kinematics.compute_inverse_kinematics(
            frame_name=self._end_effector_name,
            warm_start=seed_joint_pos,
            target_position=target_pose.translation,
            target_orientation=ut.pose3_to_quat(target_pose),
        )
        if success is False:
            carb.log_error(
                "Inverse Kinematics solver could not find a solution to target pose: "
            )
            print(target_pose)
            return seed_joint_pos
        else:
            return np.array(target_joint_position)
    def get_tcp_velocity(self, dt=1/60.0):
        if not hasattr(self, "_prev_tcp_pose"):
            self._prev_tcp_pose = self.get_tcp()
            return np.zeros(6)
        curr = self.get_tcp()
        prev = self._prev_tcp_pose
        v = (curr.translation - prev.translation) / dt
        delta_rot = curr.rotation * prev.rotation.inverse()
        w = delta_rot.scaled_axis() / dt
        self._prev_tcp_pose = curr
        return np.concatenate([v, w])